from cisco_config_parser import ConfigParser


def test_vpc_domain_settings(nxos_config):
    vpc = ConfigParser(nxos_config).get_vpc_config(return_json=True)

    assert vpc["domain_id"] == "11"
    assert vpc["role_priority"] == "8192"
    assert vpc["system_priority"] == "4096"
    assert vpc["peer_keepalive"] == {
        "destination": "10.99.98.3", "source": "10.99.98.2", "vrf": "management",
    }
    assert vpc["peer_switch"] is True
    assert vpc["peer_gateway"] is True
    assert vpc["auto_recovery"] is True
    assert vpc["ip_arp_synchronize"] is True
    assert vpc["layer3_peer_router"] is False


def test_vpc_peer_link_and_members(nxos_config):
    vpc = ConfigParser(nxos_config).get_vpc_config(return_json=True)

    assert vpc["peer_link"] == "port-channel100"
    assert vpc["vpc_port_channels"] == [{"interface": "port-channel10", "vpc_id": "10"}]


def test_vpc_in_nxos_device_model(nxos_config):
    model = ConfigParser(nxos_config).parse()
    assert model["vpc"]["domain_id"] == "11"


def test_vpc_absent_returns_none(ios_switch_config):
    assert ConfigParser(ios_switch_config).get_vpc_config() is None
