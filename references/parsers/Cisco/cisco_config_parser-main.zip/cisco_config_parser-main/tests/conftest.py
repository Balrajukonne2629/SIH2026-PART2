import pathlib

import pytest

FIXTURES = pathlib.Path(__file__).parent / "fixtures"


def _load(name):
    return (FIXTURES / name).read_text()


@pytest.fixture(scope="session")
def ios_router_config():
    return _load("ios_router.txt")


@pytest.fixture(scope="session")
def ios_switch_config():
    return _load("ios_switch.txt")


@pytest.fixture(scope="session")
def nxos_config():
    return _load("nxos_switch.txt")


@pytest.fixture(scope="session")
def xr_config():
    return _load("xr_router.txt")
