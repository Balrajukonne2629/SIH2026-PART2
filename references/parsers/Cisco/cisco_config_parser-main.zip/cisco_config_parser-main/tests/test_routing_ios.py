from cisco_config_parser import ConfigParser


def test_static_routes(ios_router_config):
    routes = ConfigParser(ios_router_config).get_static_config(return_json=True)
    assert len(routes) == 5

    by_subnet = {(r["vrf"], r["subnet"]): r for r in routes}

    default = by_subnet[("default", "0.0.0.0/0")]
    assert default["nexthop_ip"] == "10.0.0.1"

    backup = by_subnet[("default", "10.50.0.0/16")]
    assert backup["admin_distance"] == "250"

    named = by_subnet[("default", "10.60.0.0/24")]
    assert named["name"] == "LEGACY-DC"

    vrf_route = by_subnet[("CUST-A", "172.16.50.0/24")]
    assert vrf_route["nexthop_ip"] == "172.16.1.1"
    assert vrf_route["name"] == "CUST-A-LAN"

    assert ("MGMT", "0.0.0.0/0") in by_subnet


def test_ospf_config(ios_router_config):
    ospf = ConfigParser(ios_router_config).get_ospf_config(return_json=True)
    assert len(ospf) == 1
    proc = ospf[0]

    assert proc["process_id"] == "1"
    assert proc["router_id"] == "192.0.2.1"
    assert proc["auto_cost"] == "100000"

    networks = {(n["network"], n["area"]) for n in proc["network"]}
    assert ("10.0.0.0", "0") in networks
    assert ("192.0.2.1", "0") in networks

    passive = [p["interface"] for p in proc["passive_interface"]]
    assert passive == ["default"]
    no_passive = [p["interface"] for p in proc["no_passive_interface"]]
    assert no_passive == ["GigabitEthernet0/0/0"]

    # interfaces running ospf are picked up from interface sections
    assert proc["interfaces"] == [
        {"interface": "GigabitEthernet0/0/0", "area": "0", "process_id": "1"}
    ]


def test_eigrp_config(ios_router_config):
    eigrp = ConfigParser(ios_router_config).get_eigrp_config(return_json=True)
    assert len(eigrp) == 1
    proc = eigrp[0]

    assert proc["network"][0]["network"] == "10.20.30.0"
    assert proc["network"][0]["subnet_mask"] == "255.255.255.0"

    vrfs = {child["vrf"] for child in proc["vrf_children"]}
    assert vrfs == {"CUST-A"}


def test_bgp_global(ios_router_config):
    bgp = ConfigParser(ios_router_config).get_bgp_config(return_json=True)
    assert len(bgp) == 1
    proc = bgp[0]

    assert proc["router_id"] == "192.0.2.1"
    assert proc["vrf_list"] == ["CUST-A"]
    assert proc["network"] == ["10.20.30.0/24"]

    neighbors = {n["ip"]: n for n in proc["neighbors"]}
    core = neighbors["10.0.0.1"]
    assert core["remote_as"] == "65001"
    assert core["description"] == "CORE-PEER"
    assert core["update_source"] == "GigabitEthernet0/0/0"
    assert core["route_map"] == {"in": "RM-CORE-IN", "out": "RM-CORE-OUT"}

    assert proc["redistribute"] == [
        {"vrf": "Global", "protocol": "connected", "route_map": "RM-CONNECTED"}
    ]


def test_bgp_peer_group(ios_router_config):
    proc = ConfigParser(ios_router_config).get_bgp_config(return_json=True)[0]

    assert len(proc["peer_group"]) == 1
    pg = proc["peer_group"][0]["peer_group"]
    assert pg["name"] == "RR-CLIENTS"
    assert pg["remote_as"] == "65000"
    assert pg["update_source"] == "Loopback0"
    assert pg["neighbors"] == [{"ip": "192.0.2.11", "description": "RR-1"}]


def test_bgp_vrf_children(ios_router_config):
    proc = ConfigParser(ios_router_config).get_bgp_config(return_json=True)[0]

    assert len(proc["vrf_children"]) == 1
    vrf = proc["vrf_children"][0]
    assert vrf["vrf"] == "CUST-A"
    assert vrf["network"] == ["172.16.1.0/30"]

    neighbor = vrf["neighbors"][0]
    assert neighbor["ip"] == "172.16.1.1"
    assert neighbor["remote_as"] == "65100"
    assert neighbor["route_map"]["in"] == "RM-CUST-A-IN"

    assert vrf["redistribute"] == [
        {"vrf": "CUST-A", "protocol": "static", "route_map": "RM-STATIC-TO-BGP"}
    ]


def test_bgp_without_vrf_does_not_crash():
    # regression: get_dict() used to raise TypeError when the process had no vrf sections
    cfg = (
        "Current configuration : 100 bytes\n"
        "!\n"
        "router bgp 65010\n"
        " bgp router-id 198.51.100.1\n"
        " neighbor 198.51.100.2 remote-as 65020\n"
        "!\n"
    )
    proc = ConfigParser(cfg).get_bgp_config(return_json=True)[0]
    assert proc["vrf_children"] == []
    assert proc["neighbors"][0]["ip"] == "198.51.100.2"
