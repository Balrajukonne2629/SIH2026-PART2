from cisco_config_parser import ConfigParser


# ----------------------------------------------------------------------- fhrp
def test_ios_hsrp(ios_switch_config):
    groups = ConfigParser(ios_switch_config).get_fhrp_groups(return_json=True)
    assert len(groups) == 1
    hsrp = groups[0]

    assert hsrp["interface"] == "Vlan10"
    assert hsrp["protocol"] == "hsrp"
    assert hsrp["group"] == "10"
    assert hsrp["vip"] == "10.1.10.254"
    assert hsrp["priority"] == "110"
    assert hsrp["preempt"] is True
    assert hsrp["version"] == "2"
    assert hsrp["track"] == ["1 decrement 20"]


def test_ios_vrrp(ios_router_config):
    groups = ConfigParser(ios_router_config).get_fhrp_groups(return_json=True)
    assert len(groups) == 1
    vrrp = groups[0]

    assert vrrp["interface"] == "GigabitEthernet0/0/2"
    assert vrrp["protocol"] == "vrrp"
    assert vrrp["group"] == "20"
    assert vrrp["vip"] == "10.20.30.254"
    assert vrrp["priority"] == "120"
    assert vrrp["preempt"] is True


def test_nxos_hsrp_nested(nxos_config):
    groups = ConfigParser(nxos_config).get_fhrp_groups(return_json=True)
    assert len(groups) == 1
    hsrp = groups[0]

    assert hsrp["interface"] == "Vlan10"
    assert hsrp["protocol"] == "hsrp"
    assert hsrp["vip"] == "10.1.10.1"
    assert hsrp["priority"] == "110"
    assert hsrp["preempt"] is True
    assert hsrp["version"] == "2"


# -------------------------------------------------------------- port-channels
def test_ios_port_channel(ios_switch_config):
    port_channels = ConfigParser(ios_switch_config).get_port_channels(return_json=True)
    assert len(port_channels) == 1
    po1 = port_channels[0]

    assert po1["name"] == "Port-channel1"
    assert po1["id"] == "1"
    assert po1["description"] == "UPLINK-PO"
    assert po1["protocol"] == "lacp"
    assert {m["interface"] for m in po1["members"]} == {
        "GigabitEthernet1/0/47", "GigabitEthernet1/0/48",
    }


def test_nxos_port_channel_with_vpc(nxos_config):
    port_channels = ConfigParser(nxos_config).get_port_channels(return_json=True)
    by_name = {po["name"]: po for po in port_channels}
    assert set(by_name) == {"port-channel10", "port-channel100"}

    po10 = by_name["port-channel10"]
    assert po10["vpc"] == "10"
    assert po10["protocol"] == "lacp"
    assert po10["members"] == [{"interface": "Ethernet1/1", "mode": "active"}]


def test_xr_bundle_ether(xr_config):
    port_channels = ConfigParser(xr_config).get_port_channels(return_json=True)
    assert len(port_channels) == 1
    bundle = port_channels[0]

    assert bundle["name"] == "Bundle-Ether1"
    assert bundle["id"] == "1"
    assert bundle["protocol"] == "lacp"
    assert {m["interface"] for m in bundle["members"]} == {
        "GigabitEthernet0/0/0/2", "GigabitEthernet0/0/0/3",
    }


def test_fhrp_and_port_channels_in_device_model(nxos_config):
    model = ConfigParser(nxos_config).parse()
    assert model["fhrp_groups"][0]["protocol"] == "hsrp"
    assert model["port_channels"][0]["vpc"] == "10"
