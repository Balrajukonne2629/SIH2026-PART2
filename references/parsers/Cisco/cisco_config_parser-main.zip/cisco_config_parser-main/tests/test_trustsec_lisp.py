import pathlib

import pytest

from cisco_config_parser import ConfigParser

FIXTURES = pathlib.Path(__file__).parent / "fixtures"


@pytest.fixture(scope="session")
def sda_fe_config():
    return (FIXTURES / "xe_sda_fe.txt").read_text()


# -------------------------------------------------------------------- trustsec
def test_cts_global(sda_fe_config):
    cts = ConfigParser(sda_fe_config).get_trustsec(return_json=True)

    assert cts["authorization_list"] == "lab-cts-list"
    assert cts["enforcement"] is True
    assert cts["enforcement_vlan_lists"] == ["100,200-210,300"]
    assert cts["enforcement_disabled_interfaces"] == ["Vlan100"]


def test_cts_sxp(sda_fe_config):
    cts = ConfigParser(sda_fe_config).get_trustsec(return_json=True)

    assert cts["sxp_enabled"] is True
    assert cts["sxp_default_password"] is True   # boolean only: hash not stored

    connections = {c["peer"]: c for c in cts["sxp_connections"]}
    speaker = connections["192.0.2.74"]
    assert speaker["source"] == "192.0.2.11"
    assert speaker["mode"] == "peer speaker"
    assert speaker["vrf"] == "CAMPUS"
    assert connections["192.0.2.75"]["mode"] == "peer listener"


def test_cts_sgt_maps(sda_fe_config):
    cts = ConfigParser(sda_fe_config).get_trustsec(return_json=True)

    maps = cts["sgt_maps"]
    assert {"vrf": None, "address": "10.100.50.0/24", "vlan_list": None, "sgt": "20210"} in maps
    assert {"vrf": "CAMPUS", "address": "10.100.60.5", "vlan_list": None, "sgt": "20131"} in maps
    assert {"vrf": None, "address": None, "vlan_list": "300", "sgt": "29000"} in maps


def test_cts_permissions(sda_fe_config):
    cts = ConfigParser(sda_fe_config).get_trustsec(return_json=True)
    assert cts["permissions"] == [
        {"from_sgt": "2", "to_sgt": "2", "sgacls": ["FALLBACK"]},
        {"from_sgt": "17", "to_sgt": "20343", "sgacls": ["ALLOW_WEB"]},
    ]


def test_cts_interfaces(sda_fe_config):
    cts = ConfigParser(sda_fe_config).get_trustsec(return_json=True)
    interfaces = {i["interface"]: i for i in cts["interfaces"]}

    extended_node = interfaces["GigabitEthernet1/0/1"]
    assert extended_node["mode"] == "manual"
    assert extended_node["static_sgt"] == "25000"
    assert extended_node["trusted"] is True
    assert extended_node["propagate_sgt"] is False

    ap_port = interfaces["GigabitEthernet1/0/2"]
    assert ap_port["static_sgt"] == "38001"
    assert ap_port["trusted"] is False


def test_no_secrets_in_trustsec_output(sda_fe_config):
    import json
    cts_json = json.dumps(ConfigParser(sda_fe_config).get_trustsec(return_json=True))
    assert "REDACTEDREDACTED" not in cts_json


# ------------------------------------------------------------------------ lisp
def test_lisp_top_level(sda_fe_config):
    lisp = ConfigParser(sda_fe_config).get_lisp_config(return_json=True)

    assert lisp["domain_id"] == "12345"
    assert lisp["locator_sets"] == [
        {"name": "rloc_lab_set",
         "interfaces": [{"interface": "Loopback0", "priority": "10", "weight": "10"}]}
    ]


def test_lisp_services(sda_fe_config):
    lisp = ConfigParser(sda_fe_config).get_lisp_config(return_json=True)
    services = {s["name"]: s for s in lisp["services"]}

    ipv4 = services["ipv4"]
    assert ipv4["encapsulation"] == "vxlan"
    assert ipv4["itr_map_resolvers"] == ["192.0.2.81", "192.0.2.82"]
    assert ipv4["etr"] is True
    assert ipv4["sgt"] is True
    assert ipv4["proxy_itr"] == "192.0.2.83"

    map_servers = {m["server"]: m for m in ipv4["etr_map_servers"]}
    assert map_servers["192.0.2.81"] == {
        "server": "192.0.2.81", "has_key": True, "proxy_reply": True,
    }

    ethernet = services["ethernet"]
    assert ethernet["itr"] is True


def test_lisp_instances(sda_fe_config):
    lisp = ConfigParser(sda_fe_config).get_lisp_config(return_json=True)

    assert len(lisp["instances"]) == 1
    instance = lisp["instances"][0]
    assert instance["instance_id"] == "4100"

    eids = {e["name"]: e for e in instance["dynamic_eids"]}
    assert eids["LAB_USERS-IPV4"]["database_mappings"] == [
        {"prefix": "10.100.0.0/24", "locator_set": "rloc_lab_set"}
    ]

    assert instance["services"][0]["eid_table"] == "vrf CAMPUS"


def test_no_secrets_in_lisp_output(sda_fe_config):
    import json
    lisp_json = json.dumps(ConfigParser(sda_fe_config).get_lisp_config(return_json=True))
    assert "REDACTEDREDACTED" not in lisp_json


def test_lisp_absent_returns_none(ios_switch_config):
    assert ConfigParser(ios_switch_config).get_lisp_config() is None


# ---------------------------------------------------------------- device model
def test_sda_device_model(sda_fe_config):
    model = ConfigParser(sda_fe_config).parse()
    assert model["trustsec"]["authorization_list"] == "lab-cts-list"
    assert model["lisp"]["domain_id"] == "12345"
    assert model["parse_errors"] == []


# ------------------------------------------------------------------ XR acls
def test_xr_ipv4_access_list(xr_config):
    # regression for the real-config gap: XR "ipv4 access-list" form
    cfg = xr_config + (
        "ipv4 access-list SNMP-RO\n"
        " 10 permit ipv4 10.10.0.0 0.0.0.255 any\n"
        " 20 deny ipv4 any any\n"
    )
    acls = {a["name"]: a for a in ConfigParser(cfg).get_access_lists(return_json=True)}
    snmp = acls["SNMP-RO"]
    assert snmp["entries"][0]["sequence"] == "10"
    assert snmp["entries"][0]["protocol"] == "ipv4"
    assert snmp["entries"][0]["source"] == "10.10.0.0 0.0.0.255"
