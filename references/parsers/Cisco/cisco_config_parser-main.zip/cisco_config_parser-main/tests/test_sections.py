from cisco_config_parser import ConfigParser


# ------------------------------------------------------------------ ACLs
def test_named_standard_acl(ios_router_config):
    acls = {a["name"]: a for a in ConfigParser(ios_router_config).get_access_lists(return_json=True)}

    snmp_acl = acls["ACL-SNMP-RO"]
    assert snmp_acl["type"] == "standard"
    assert snmp_acl["style"] == "named"
    sources = [e["source"] for e in snmp_acl["entries"]]
    assert sources == ["10.10.10.0 0.0.0.255", "10.99.99.0 0.0.0.255"]


def test_named_extended_acl(ios_router_config):
    acls = {a["name"]: a for a in ConfigParser(ios_router_config).get_access_lists(return_json=True)}

    mgmt = acls["ACL-MGMT-IN"]
    assert mgmt["type"] == "extended"
    assert mgmt["remarks"] == ["--- allow ssh from mgmt subnets ---"]

    ssh_entry = mgmt["entries"][0]
    assert ssh_entry["action"] == "permit"
    assert ssh_entry["protocol"] == "tcp"
    assert ssh_entry["source"] == "10.99.99.0 0.0.0.255"
    assert ssh_entry["destination"] == "any"
    assert ssh_entry["destination_port"] == "eq 22"

    deny_entry = mgmt["entries"][-1]
    assert deny_entry["action"] == "deny"
    assert deny_entry["options"] == "log"


def test_numbered_acls(ios_router_config):
    acls = {a["name"]: a for a in ConfigParser(ios_router_config).get_access_lists(return_json=True)}

    std = acls["10"]
    assert std["type"] == "standard"
    assert std["style"] == "numbered"
    assert len(std["entries"]) == 2

    ext = acls["110"]
    assert ext["type"] == "extended"
    https_entry = ext["entries"][0]
    assert https_entry["destination"] == "10.20.30.10"  # "host X" collapses to X
    assert https_entry["destination_port"] == "eq 443"


# ---------------------------------------------------------------- prefix-lists
def test_prefix_lists_grouped_by_name(ios_router_config):
    pls = {p["name"]: p for p in ConfigParser(ios_router_config).get_prefix_lists(return_json=True)}

    assert set(pls) == {"PL-DEFAULT-ONLY", "PL-CUST-A", "PL-DENY-RFC1918"}

    cust_a = pls["PL-CUST-A"]
    assert len(cust_a["entries"]) == 2
    assert cust_a["entries"][1]["prefix"] == "172.16.51.0/24"
    assert cust_a["entries"][1]["le"] == "32"

    rfc1918 = pls["PL-DENY-RFC1918"]
    assert all(e["action"] == "deny" for e in rfc1918["entries"])


def test_xr_prefix_sets(xr_config):
    sets = {p["name"]: p for p in ConfigParser(xr_config).get_prefix_sets(return_json=True)}
    assert sets["PS-DEFAULT-ONLY"]["prefixes"] == ["0.0.0.0/0"]
    assert "10.0.0.0/8 le 32" in sets["PS-RFC1918"]["prefixes"]


# -------------------------------------------------------------- NXOS sections
def test_nxos_named_acl_with_sequences(nxos_config):
    acls = {a["name"]: a for a in ConfigParser(nxos_config).get_access_lists(return_json=True)}

    mgmt = acls["ACL-MGMT-IN"]
    assert mgmt["style"] == "named"

    ssh_entry = mgmt["entries"][0]
    assert ssh_entry["sequence"] == "10"
    assert ssh_entry["source"] == "10.99.99.0/24"      # NXOS CIDR source
    assert ssh_entry["destination_port"] == "eq 22"

    assert mgmt["entries"][-1]["action"] == "deny"
    assert mgmt["entries"][-1]["options"] == "log"


def test_nxos_prefix_lists(nxos_config):
    pls = {p["name"]: p for p in ConfigParser(nxos_config).get_prefix_lists(return_json=True)}
    assert set(pls) == {"PL-DEFAULT-ONLY", "PL-DENY-RFC1918"}
    assert pls["PL-DENY-RFC1918"]["entries"][0]["le"] == "32"


def test_nxos_route_maps(nxos_config):
    rms = {r["name"]: r for r in ConfigParser(nxos_config).get_route_maps(return_json=True)}
    assert set(rms) == {"RM-CORE-IN", "RM-CORE-OUT", "RM-CONNECTED", "RM-CUST-A-IN"}

    core_in = rms["RM-CORE-IN"]
    assert [c["action"] for c in core_in["clauses"]] == ["deny", "permit"]
    assert core_in["clauses"][1]["set"] == ["local-preference 200"]

    assert rms["RM-CORE-OUT"]["clauses"][0]["match"] == ["community CL-CUSTOMER"]


# ------------------------------------------------------------- community-lists
def test_ios_community_lists(ios_router_config):
    cls = {c["name"]: c for c in ConfigParser(ios_router_config).get_community_lists(return_json=True)}

    customer = cls["CL-CUSTOMER"]
    assert customer["type"] == "standard"
    assert customer["style"] == "named"
    assert [e["communities"] for e in customer["entries"]] == [["65000:100"], ["65000:200"]]

    expanded = cls["CL-ANY-65100"]
    assert expanded["type"] == "expanded"
    assert expanded["entries"][0]["communities"] == ["_65100_"]

    # numbered: 1-99 standard, 100-500 expanded
    assert cls["1"]["type"] == "standard"
    assert cls["1"]["style"] == "numbered"
    assert cls["120"]["type"] == "expanded"


def test_nxos_community_lists(nxos_config):
    cls = {c["name"]: c for c in ConfigParser(nxos_config).get_community_lists(return_json=True)}

    customer = cls["CL-CUSTOMER"]
    assert [e["sequence"] for e in customer["entries"]] == ["10", "20"]

    # quoted regex is unquoted
    assert cls["CL-ANY-65100"]["entries"][0]["communities"] == ["651.._[0-9]+"]


def test_xr_community_sets(xr_config):
    sets = {c["name"]: c for c in ConfigParser(xr_config).get_community_sets(return_json=True)}
    assert sets["CS-CUSTOMER"]["communities"] == ["65000:100", "65000:200"]


# ------------------------------------------------------------------ route-maps
def test_route_maps(ios_router_config):
    rms = {r["name"]: r for r in ConfigParser(ios_router_config).get_route_maps(return_json=True)}

    core_in = rms["RM-CORE-IN"]
    assert [c["action"] for c in core_in["clauses"]] == ["deny", "permit"]
    assert core_in["clauses"][0]["match"] == ["ip address prefix-list PL-DENY-RFC1918"]
    assert core_in["clauses"][1]["set"] == ["local-preference 200"]

    cust_a_in = rms["RM-CUST-A-IN"]
    assert cust_a_in["clauses"][0]["description"] == "allow customer routes"
    assert cust_a_in["clauses"][0]["set"] == ["weight 100"]


def test_xr_route_policies(xr_config):
    rps = {r["name"]: r for r in ConfigParser(xr_config).get_route_policies(return_json=True)}
    assert "drop" in rps["RP-CORE-IN"]["lines"]
    assert rps["RP-PASS-ALL"]["lines"] == ["pass"]


# ------------------------------------------------------------------------ vrfs
def test_ios_vrf_definitions(ios_router_config):
    vrfs = {v["name"]: v for v in ConfigParser(ios_router_config).get_vrfs(return_json=True)}

    cust_a = vrfs["CUST-A"]
    assert cust_a["rd"] == "65000:100"
    af = cust_a["address_families"][0]
    assert af["route_target_import"] == ["65000:100"]
    assert af["route_target_export"] == ["65000:100"]

    assert vrfs["MGMT"]["rd"] == "65000:900"


def test_nxos_vrf_context(nxos_config):
    vrfs = {v["name"]: v for v in ConfigParser(nxos_config).get_vrfs(return_json=True)}
    assert "MGMT" in vrfs
    assert "ip route 0.0.0.0/0 10.99.99.254" in vrfs["MGMT"]["children"]


def test_xr_vrf(xr_config):
    vrfs = {v["name"]: v for v in ConfigParser(xr_config).get_vrfs(return_json=True)}
    af = vrfs["CUST-A"]["address_families"][0]
    assert af["route_target_import"] == ["65000:100"]
    assert af["route_target_export"] == ["65000:100"]


# ------------------------------------------------------------- device identity
def test_device_identity_basics(ios_router_config):
    identity = ConfigParser(ios_router_config).get_device_identity(return_json=True)

    assert identity["hostname"] == "lab-rtr-01"
    assert identity["version"] == "17.3"
    assert identity["domain_name"] == "lab.example.com"
    assert identity["name_servers"] == ["10.10.10.10", "10.10.10.11"]

    users = {u["name"]: u for u in identity["users"]}
    assert users["admin"]["privilege"] == "15"
    assert users["admin"]["secret_type"] == "secret"

    assert "aaa new-model" in identity["aaa"]


def test_device_identity_mgmt_plane(ios_router_config):
    identity = ConfigParser(ios_router_config).get_device_identity(return_json=True)

    assert identity["ntp_servers"][0] == {"server": "10.10.10.20", "prefer": True}
    assert identity["logging_hosts"] == ["10.10.10.61", "10.10.10.62"]
    assert identity["logging_trap"] == "informational"

    snmp = identity["snmp"]
    assert snmp["communities"][0]["mode"] == "RO"
    assert snmp["communities"][0]["acl"] == "ACL-SNMP-RO"
    assert snmp["location"].startswith("LAB-DC-1")
    assert snmp["hosts"][0]["host"] == "10.10.10.60"

    lines = {l["name"]: l for l in identity["lines"]}
    vty = lines["vty 0 4"]
    assert vty["access_class"] == "ACL-MGMT-IN"
    assert vty["transport_input"] == "ssh"
    assert vty["exec_timeout"] == "10 0"


def test_nxos_features(nxos_config):
    identity = ConfigParser(nxos_config).get_device_identity(return_json=True)
    assert identity["hostname"] == "lab-nx-01"
    assert "bgp" in identity["features"]
    assert "vpc" in identity["features"]
