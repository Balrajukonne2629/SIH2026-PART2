from cisco_config_parser import ConfigParser


def test_vlan_info(ios_switch_config):
    vlans = ConfigParser(ios_switch_config).get_vlan_info()
    by_id = {v.vlan: v.children for v in vlans}

    assert set(by_id) == {"vlan 10", "vlan 20", "vlan 30", "vlan 99", "vlan 900"}
    assert by_id["vlan 10"] == ["name DATA"]
    assert by_id["vlan 900"] == ["name MGMT"]


def test_banner(ios_switch_config):
    banner = ConfigParser(ios_switch_config).get_banner()
    assert banner.banner[0].startswith("banner login")
    assert "Unauthorized access is prohibited." in banner.banner


def test_parent_child_custom_regex(ios_switch_config):
    results = ConfigParser(ios_switch_config).get_parent_child(parent_regex=r"^vlan 10$")
    assert len(results) == 1
    assert results[0].parent.strip() == "vlan 10"
