import pytest

from cisco_config_parser import ConfigParser


def test_detects_ios(ios_router_config):
    assert ConfigParser(ios_router_config).determine_platform() == "IOS"


def test_detects_nxos(nxos_config):
    assert ConfigParser(nxos_config).determine_platform() == "NXOS"


def test_detects_xr(xr_config):
    assert ConfigParser(xr_config).determine_platform() == "XR"


@pytest.mark.parametrize(
    "alias, expected",
    [
        ("IOS", "IOS"),
        ("ios-xe", "IOS"),
        ("NXOS", "NXOS"),
        ("nx-os", "NXOS"),
        ("XR", "XR"),
        ("IOS-XR", "XR"),
        ("iosxr", "XR"),
    ],
)
def test_platform_aliases(ios_router_config, alias, expected):
    # explicit platform wins over auto-detection
    assert ConfigParser(ios_router_config, platform=alias).determine_platform() == expected


def test_unknown_platform_rejected(ios_router_config):
    with pytest.raises(ValueError):
        ConfigParser(ios_router_config, platform="junos")


def test_undetectable_platform_raises():
    with pytest.raises(ValueError):
        ConfigParser("hostname mystery\n").determine_platform()


def test_unimplemented_platform_feature_raises(xr_config):
    with pytest.raises(NotImplementedError):
        ConfigParser(xr_config).get_eigrp_config()
