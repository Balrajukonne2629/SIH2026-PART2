import json

from cisco_config_parser import ConfigParser


def test_ios_router_model(ios_router_config):
    model = ConfigParser(ios_router_config).parse()

    assert model["platform"] == "IOS"
    assert model["hostname"] == "lab-rtr-01"
    assert model["unsupported"] == []
    assert model["parse_errors"] == []

    assert {a["name"] for a in model["access_lists"]} == {
        "ACL-SNMP-RO", "ACL-MGMT-IN", "10", "110",
    }
    assert {v["name"] for v in model["vrfs"]} == {"CUST-A", "MGMT"}
    assert {c["name"] for c in model["community_lists"]} == {"CL-CUSTOMER", "CL-ANY-65100", "1", "120"}
    assert model["routing"]["bgp"][0]["router_id"] == "192.0.2.1"
    assert len(model["routing"]["static"]) == 5

    # the whole model must be JSON-serializable for agent consumption
    assert json.dumps(model)


def test_ios_switch_model(ios_switch_config):
    model = ConfigParser(ios_switch_config).parse()

    assert model["hostname"] == "lab-sw-01"
    vlans = {v["id"]: v["name"] for v in model["vlans"]}
    assert vlans == {"10": "DATA", "20": "VOICE", "30": "SERVERS", "99": "NATIVE", "900": "MGMT"}
    assert len(model["l2_access_interfaces"]) == 3
    assert len(model["l2_trunk_interfaces"]) == 3


def test_nxos_model(nxos_config):
    model = ConfigParser(nxos_config).parse()

    assert model["platform"] == "NXOS"
    assert model["hostname"] == "lab-nx-01"
    # only eigrp remains unimplemented for NXOS: flagged, not crashed
    assert model["unsupported"] == ["eigrp"]
    assert model["parse_errors"] == []
    assert len(model["l3_interfaces"]) == 4

    assert model["routing"]["bgp"][0]["as_number"] == "65000"
    assert len(model["routing"]["static"]) == 5
    assert model["routing"]["ospf"][0]["router_id"] == "192.0.2.2"


def test_xr_model_includes_rpl(xr_config):
    model = ConfigParser(xr_config).parse()

    assert model["platform"] == "XR"
    assert {p["name"] for p in model["prefix_sets"]} == {"PS-DEFAULT-ONLY", "PS-RFC1918"}
    assert {p["name"] for p in model["community_sets"]} == {"CS-CUSTOMER"}
    assert {p["name"] for p in model["route_policies"]} == {
        "RP-CORE-IN", "RP-PASS-ALL", "RP-CUST-A-EXPORT",
    }

    # only eigrp remains unimplemented for XR
    assert model["unsupported"] == ["eigrp"]
    assert model["parse_errors"] == []
    assert model["routing"]["bgp"][0]["as_number"] == "65000"
    assert len(model["routing"]["static"]) == 4
    assert model["routing"]["ospf"][0]["router_id"] == "192.0.2.3"


def test_include_raw_tree(ios_switch_config):
    model = ConfigParser(ios_switch_config).parse(include_raw_tree=True)
    top_lines = [d["line"] for d in model["config_tree"]]
    assert "hostname lab-sw-01" in top_lines
