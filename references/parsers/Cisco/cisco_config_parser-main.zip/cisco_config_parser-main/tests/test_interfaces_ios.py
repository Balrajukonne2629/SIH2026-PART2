from cisco_config_parser import ConfigParser


def test_l3_interfaces_on_switch(ios_switch_config):
    svis = ConfigParser(ios_switch_config).get_l3_interfaces(return_json=True)
    by_name = {i["name"]: i for i in svis}

    assert set(by_name) == {"Vlan10", "Vlan30", "Vlan900"}

    vlan10 = by_name["Vlan10"]
    assert vlan10["description"] == "DATA-SVI"
    assert vlan10["ip_address"] == "10.1.10.1"
    assert vlan10["mask"] == "255.255.255.0"
    assert vlan10["subnet"] == "10.1.10.0/24"
    assert vlan10["helpers"] == ["10.10.10.50"]


def test_l3_interfaces_on_router(ios_router_config):
    intfs = ConfigParser(ios_router_config).get_l3_interfaces(return_json=True)
    by_name = {i["name"]: i for i in intfs}

    cust_a = by_name["GigabitEthernet0/0/1"]
    assert cust_a["vrf"] == "CUST-A"
    assert cust_a["ip_address"] == "172.16.1.2"

    legacy = by_name["GigabitEthernet0/0/2"]
    assert legacy["sec_ip_address"] == "10.20.31.1"
    assert legacy["sec_subnet"] == "10.20.31.0/24"
    assert legacy["ipv6_address"] == "2001:DB8:20:30::1/64"
    assert legacy["helpers"] == ["10.10.10.50", "10.10.10.51"]


def test_l2_access_interfaces(ios_switch_config):
    access = ConfigParser(ios_switch_config).get_l2_access_interfaces(return_json=True)
    by_name = {i["name"]: i for i in access}

    assert set(by_name) == {
        "GigabitEthernet1/0/1",
        "GigabitEthernet1/0/2",
        "GigabitEthernet1/0/3",
    }

    user_port = by_name["GigabitEthernet1/0/1"]
    assert user_port["data_vlan"] == "10"
    assert user_port["voice_vlan"] == "20"

    server_port = by_name["GigabitEthernet1/0/3"]
    assert server_port["data_vlan"] == "30"
    assert server_port["voice_vlan"] is None


def test_l2_trunk_interfaces(ios_switch_config):
    trunks = ConfigParser(ios_switch_config).get_l2_trunk_interfaces()
    names = {t.name for t in trunks}
    assert names == {"Port-channel1", "GigabitEthernet1/0/47", "GigabitEthernet1/0/48"}


def test_subnet_and_usage(ios_switch_config):
    usage = ConfigParser(ios_switch_config).get_subnet_and_usage(include_subnet_count=True)
    assert usage["Vlan10"] == "10.1.10.0/24"
    assert usage["subnet_count"]["/24"] == 3
