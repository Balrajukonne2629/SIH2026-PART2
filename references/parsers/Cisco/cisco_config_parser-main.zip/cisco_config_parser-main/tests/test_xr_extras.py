from cisco_config_parser import ConfigParser


def test_xr_extcommunity_sets(xr_config):
    sets = {s["name"]: s for s in ConfigParser(xr_config).get_extcommunity_sets(return_json=True)}

    cust_a = sets["CUST-A-RT"]
    assert cust_a["type"] == "rt"
    assert cust_a["communities"] == ["65000:100"]


def test_xr_ntp_section(xr_config):
    identity = ConfigParser(xr_config).get_device_identity(return_json=True)
    servers = {s["server"]: s for s in identity["ntp_servers"]}

    assert servers["10.10.10.20"]["prefer"] is True
    assert servers["10.10.10.21"]["prefer"] is False


def test_extcommunity_sets_in_xr_model(xr_config):
    model = ConfigParser(xr_config).parse()
    assert {s["name"] for s in model["extcommunity_sets"]} == {"CUST-A-RT"}


def test_extcommunity_set_xref(xr_config):
    # CUST-A-RT is defined and referenced (set extcommunity rt) -> clean
    report = ConfigParser(xr_config).validate()
    assert "extcommunity_set" not in report["undefined_references"]
    assert "extcommunity_set" not in report["unused_definitions"]

    # an orphan reference is detected
    broken = xr_config + (
        "route-policy RP-BROKEN\n"
        "  if extcommunity rt matches-every MISSING-RT then\n"
        "    pass\n"
        "  endif\n"
        "end-policy\n"
    )
    report = ConfigParser(broken).validate()
    undefined = [r["name"] for r in report["undefined_references"]["extcommunity_set"]]
    assert undefined == ["MISSING-RT"]
