from cisco_config_parser.config_tree import ConfigTree


def test_interfaces_become_sections(ios_router_config):
    tree = ConfigTree(ios_router_config)
    interfaces = tree.find_objects(r"^interface ")
    names = [i.line for i in interfaces]
    assert "interface Loopback0" in names
    assert "interface GigabitEthernet0/0/3" in names

    lo0 = interfaces[0]
    assert "ip address 192.0.2.1 255.255.255.255" in lo0.child_lines()


def test_nested_sections(ios_router_config):
    tree = ConfigTree(ios_router_config)
    bgp = tree.find_objects(r"^router bgp")[0]

    afs = bgp.find_children(r"^address-family")
    assert len(afs) == 2

    vrf_af = bgp.find_children(r"^address-family ipv4 vrf CUST-A")[0]
    assert "neighbor 172.16.1.1 remote-as 65100" in vrf_af.child_lines()

    # find_all reaches into nested address-families
    all_neighbors = bgp.find_all(r"^neighbor 172\.16\.1\.1")
    assert len(all_neighbors) == 3


def test_three_level_nesting(ios_router_config):
    tree = ConfigTree(ios_router_config)
    vrf = tree.find_objects(r"^vrf definition CUST-A")[0]
    af = vrf.find_children(r"^address-family ipv4")[0]
    assert "route-target export 65000:100" in af.child_lines()


def test_standalone_lines(ios_router_config):
    tree = ConfigTree(ios_router_config)
    statics = tree.find_objects(r"^ip route ")
    assert len(statics) == 5
    assert all(not s.children for s in statics)


def test_banner_swallowed(ios_router_config):
    tree = ConfigTree(ios_router_config)
    banners = tree.find_objects(r"^banner motd")
    assert len(banners) == 1
    banner_text = banners[0].child_lines()
    assert "*** AUTHORIZED ACCESS ONLY ***" in banner_text
    # banner body must not leak into top-level sections
    assert "This is a lab device." not in tree.top_level_lines()


def test_nxos_two_space_indent(nxos_config):
    tree = ConfigTree(nxos_config)
    vlan10 = tree.find_objects(r"^vlan 10$")[0]
    assert vlan10.child_lines() == ["name DATA", "vn-segment 10010"]

    bgp = tree.find_objects(r"^router bgp")[0]
    neighbor = bgp.find_children(r"^neighbor 192\.0\.2\.1")[0]
    assert "remote-as 65000" in neighbor.child_lines()
    # 3rd level under the neighbor
    assert neighbor.find_children(r"^address-family ipv4 unicast")


def test_xr_route_policy(xr_config):
    tree = ConfigTree(xr_config)
    policies = tree.find_objects(r"^route-policy")
    assert [p.line for p in policies] == [
        "route-policy RP-CORE-IN",
        "route-policy RP-PASS-ALL",
        "route-policy RP-CUST-A-EXPORT",
    ]


def test_section_text_roundtrip(ios_switch_config):
    tree = ConfigTree(ios_switch_config)
    po1 = tree.find_objects(r"^interface Port-channel1")[0]
    text = po1.section_text()
    assert text.splitlines()[0] == "interface Port-channel1"
    assert " switchport mode trunk" in text.splitlines()


def test_to_dict(ios_switch_config):
    tree = ConfigTree(ios_switch_config)
    as_dict = tree.to_dict()
    top_lines = [d["line"] for d in as_dict]
    assert "hostname lab-sw-01" in top_lines
