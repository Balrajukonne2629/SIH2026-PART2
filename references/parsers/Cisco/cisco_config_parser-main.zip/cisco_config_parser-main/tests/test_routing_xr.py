import pytest

from cisco_config_parser import ConfigParser


def test_xr_static_routes(xr_config):
    routes = ConfigParser(xr_config).get_static_config(return_json=True)
    by_key = {(r["vrf"], r["prefix"]): r for r in routes}

    assert len(routes) == 4

    default = by_key[("default", "0.0.0.0/0")]
    assert default["nexthop_ip"] == "10.0.1.1"
    assert default["address_family"] == "ipv4 unicast"

    with_ad = by_key[("default", "10.50.0.0/16")]
    assert with_ad["admin_distance"] == "250"
    assert with_ad["mask"] == "255.255.0.0"

    egress = by_key[("default", "10.60.0.0/24")]
    assert egress["nexthop_interface"] == "GigabitEthernet0/0/0/0"
    assert egress["nexthop_ip"] == "10.0.1.1"

    vrf_route = by_key[("CUST-A", "172.16.60.0/24")]
    assert vrf_route["nexthop_ip"] == "172.16.2.1"


def test_xr_ospf(xr_config):
    ospf = ConfigParser(xr_config).get_ospf_config(return_json=True)
    assert len(ospf) == 1
    proc = ospf[0]

    assert proc["process_id"] == "1"
    assert proc["router_id"] == "192.0.2.3"

    assert len(proc["areas"]) == 1
    area0 = proc["areas"][0]
    assert area0["area"] == "0"

    interfaces = {i["interface"]: i for i in area0["interfaces"]}
    assert interfaces["Loopback0"]["passive"] is True
    assert interfaces["GigabitEthernet0/0/0/0"]["cost"] == "10"

    assert proc["vrfs"][0]["vrf"] == "CUST-A"
    assert proc["vrfs"][0]["router_id"] == "192.0.2.33"


def test_xr_bgp_process(xr_config):
    bgp = ConfigParser(xr_config).get_bgp_config(return_json=True)
    assert len(bgp) == 1
    proc = bgp[0]

    assert proc["as_number"] == "65000"
    assert proc["router_id"] == "192.0.2.3"

    afs = {af["name"]: af for af in proc["address_families"]}
    assert set(afs) == {"ipv4 unicast", "vpnv4 unicast"}
    assert afs["ipv4 unicast"]["networks"] == ["192.0.2.3/32"]


def test_xr_bgp_neighbor_group(xr_config):
    proc = ConfigParser(xr_config).get_bgp_config(return_json=True)[0]

    groups = {g["name"]: g for g in proc["neighbor_groups"]}
    assert groups["RR-CLIENTS"]["remote_as"] == "65000"
    assert groups["RR-CLIENTS"]["update_source"] == "Loopback0"

    neighbors = {n["ip"]: n for n in proc["neighbors"]}
    assert neighbors["192.0.2.11"]["use_neighbor_group"] == "RR-CLIENTS"
    assert neighbors["192.0.2.11"]["description"] == "RR-1"


def test_xr_bgp_route_policies_on_neighbor(xr_config):
    proc = ConfigParser(xr_config).get_bgp_config(return_json=True)[0]

    core = {n["ip"]: n for n in proc["neighbors"]}["10.0.1.1"]
    assert core["remote_as"] == "65001"
    af = core["address_families"][0]
    assert af["route_policy"] == {"in": "RP-CORE-IN", "out": "RP-PASS-ALL"}


def test_xr_bgp_vrf(xr_config):
    proc = ConfigParser(xr_config).get_bgp_config(return_json=True)[0]

    assert len(proc["vrfs"]) == 1
    vrf = proc["vrfs"][0]
    assert vrf["vrf"] == "CUST-A"
    assert vrf["rd"] == "65000:100"
    assert vrf["address_families"][0]["redistribute"] == [
        {"protocol": "connected", "route_policy": None}
    ]

    ce = vrf["neighbors"][0]
    assert ce["ip"] == "172.16.2.1"
    assert ce["vrf"] == "CUST-A"
    assert ce["remote_as"] == "65100"
    assert ce["address_families"][0]["route_policy"]["in"] == "RP-PASS-ALL"


def test_xr_eigrp_still_unsupported(xr_config):
    with pytest.raises(NotImplementedError):
        ConfigParser(xr_config).get_eigrp_config()
