from cisco_config_parser import ConfigParser


def test_xe_flow_record(ios_router_config):
    netflow = ConfigParser(ios_router_config).get_netflow(return_json=True)

    record = netflow["records"][0]
    assert record["name"] == "LAB_RECORD"
    assert record["description"] == "lab flow record"
    assert "ipv4 source address" in record["match"]
    assert "counter bytes" in record["collect"]


def test_xe_flow_exporter_and_monitor(ios_router_config):
    netflow = ConfigParser(ios_router_config).get_netflow(return_json=True)

    exporter = netflow["exporters"][0]
    assert exporter["name"] == "LAB_EXPORTER"
    assert exporter["destination"] == "10.10.10.70"
    assert exporter["source"] == "Loopback0"
    assert exporter["transport_udp_port"] == "2055"

    monitor = netflow["monitors"][0]
    assert monitor["name"] == "LAB_MONITOR"
    assert monitor["record"] == "LAB_RECORD"
    assert monitor["exporters"] == ["LAB_EXPORTER"]
    assert monitor["cache"] == ["timeout active 60"]


def test_xe_interface_attachment(ios_router_config):
    netflow = ConfigParser(ios_router_config).get_netflow(return_json=True)
    assert netflow["interface_attachments"] == [{
        "interface": "GigabitEthernet0/0/0",
        "family": "ipv4",
        "monitor": "LAB_MONITOR",
        "sampler": None,
        "direction": "input",
    }]


def test_xr_netflow_maps(xr_config):
    netflow = ConfigParser(xr_config).get_netflow(return_json=True)

    exporter = netflow["exporters"][0]
    assert exporter["name"] == "LAB-EM"
    assert exporter["version"] == "v9"
    assert exporter["destination"] == "10.10.10.70"
    assert exporter["transport_udp_port"] == "2055"

    monitor = netflow["monitors"][0]
    assert monitor["name"] == "LAB-FMM"
    assert monitor["record"] == "ipv4"
    assert monitor["exporters"] == ["LAB-EM"]

    sampler = netflow["samplers"][0]
    assert sampler["name"] == "LAB-SM"
    assert sampler["mode"] == "random 1 out-of 1000"


def test_xr_interface_attachment(xr_config):
    netflow = ConfigParser(xr_config).get_netflow(return_json=True)
    assert netflow["interface_attachments"] == [{
        "interface": "GigabitEthernet0/0/0/0",
        "family": "ipv4",
        "monitor": "LAB-FMM",
        "sampler": "LAB-SM",
        "direction": "ingress",
    }]


def test_netflow_in_device_model(ios_router_config):
    model = ConfigParser(ios_router_config).parse()
    assert model["netflow"]["monitors"][0]["name"] == "LAB_MONITOR"
    assert model["parse_errors"] == []


def test_netflow_absent(ios_switch_config):
    netflow = ConfigParser(ios_switch_config).get_netflow(return_json=True)
    assert netflow["records"] == []
    assert netflow["interface_attachments"] == []
