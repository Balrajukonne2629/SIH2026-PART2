from cisco_config_parser import ConfigParser


def test_nxos_static_routes(nxos_config):
    routes = ConfigParser(nxos_config).get_static_config(return_json=True)
    by_key = {(r["vrf"], r["prefix"]): r for r in routes}

    assert len(routes) == 5

    default = by_key[("default", "0.0.0.0/0")]
    assert default["nexthop_ip"] == "10.1.10.254"
    assert default["network"] == "0.0.0.0"

    named = by_key[("default", "10.50.0.0/16")]
    assert named["name"] == "DC-CORE"
    assert named["admin_distance"] == "250"
    assert named["mask"] == "255.255.0.0"

    egress = by_key[("default", "10.60.0.0/24")]
    assert egress["nexthop_interface"] == "Ethernet1/3"
    assert egress["nexthop_ip"] == "10.1.10.252"

    vrf_route = by_key[("CUST-A", "172.16.60.0/24")]
    assert vrf_route["name"] == "CUST-A-LAN"

    assert ("MGMT", "0.0.0.0/0") in by_key


def test_nxos_ospf(nxos_config):
    ospf = ConfigParser(nxos_config).get_ospf_config(return_json=True)
    assert len(ospf) == 1
    proc = ospf[0]

    assert proc["process_id"] == "1"
    assert proc["router_id"] == "192.0.2.2"
    assert proc["auto_cost"] == "100000"

    # areas live on the interfaces on NXOS
    interfaces = {i["interface"]: i for i in proc["interfaces"]}
    assert interfaces["Vlan10"]["area"] == "0.0.0.0"
    assert interfaces["Vlan10"]["passive"] is True
    assert interfaces["loopback0"]["passive"] is False

    assert proc["vrfs"] == [
        {"vrf": "CUST-A", "router_id": "192.0.2.22", "children": ["router-id 192.0.2.22"]}
    ]


def test_nxos_bgp_process(nxos_config):
    bgp = ConfigParser(nxos_config).get_bgp_config(return_json=True)
    assert len(bgp) == 1
    proc = bgp[0]

    assert proc["as_number"] == "65000"
    assert proc["router_id"] == "192.0.2.2"

    af = proc["address_families"][0]
    assert af["name"] == "ipv4 unicast"
    assert af["networks"] == ["10.1.10.0/24"]
    assert af["redistribute"] == [{"protocol": "direct", "route_map": "RM-CONNECTED"}]


def test_nxos_bgp_neighbors_and_template(nxos_config):
    proc = ConfigParser(nxos_config).get_bgp_config(return_json=True)[0]

    templates = {t["name"]: t for t in proc["templates"]}
    assert templates["RR-CLIENT"]["remote_as"] == "65000"
    assert templates["RR-CLIENT"]["update_source"] == "loopback0"

    neighbors = {n["ip"]: n for n in proc["neighbors"]}

    rr = neighbors["192.0.2.1"]
    assert rr["remote_as"] == "65000"
    assert rr["description"] == "RR-1"

    core = neighbors["10.0.2.1"]
    assert core["inherit_peer"] == "RR-CLIENT"
    assert core["address_families"][0]["route_map"] == {"in": "RM-CORE-IN", "out": "RM-CORE-OUT"}


def test_nxos_bgp_vrf(nxos_config):
    proc = ConfigParser(nxos_config).get_bgp_config(return_json=True)[0]

    assert len(proc["vrfs"]) == 1
    vrf = proc["vrfs"][0]
    assert vrf["vrf"] == "CUST-A"
    assert vrf["router_id"] == "192.0.2.22"
    assert vrf["address_families"][0]["networks"] == ["172.16.2.0/30"]

    ce = vrf["neighbors"][0]
    assert ce["ip"] == "172.16.2.1"
    assert ce["vrf"] == "CUST-A"
    assert ce["remote_as"] == "65100"
    assert ce["address_families"][0]["route_map"]["in"] == "RM-CUST-A-IN"


def test_nxos_eigrp_still_unsupported(nxos_config):
    import pytest
    with pytest.raises(NotImplementedError):
        ConfigParser(nxos_config).get_eigrp_config()
