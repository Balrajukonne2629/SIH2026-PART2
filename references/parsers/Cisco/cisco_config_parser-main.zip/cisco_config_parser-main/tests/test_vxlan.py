from cisco_config_parser import ConfigParser


def test_nve_interface(nxos_config):
    vxlan = ConfigParser(nxos_config).get_vxlan_config(return_json=True)
    nve = vxlan["nve"]

    assert nve["name"] == "nve1"
    assert nve["source_interface"] == "loopback0"
    assert nve["host_reachability"] == "bgp"

    vnis = {v["vni"]: v for v in nve["vnis"]}
    assert vnis["10010"]["suppress_arp"] is True
    assert vnis["10010"]["ingress_replication"] == "bgp"
    assert vnis["10020"]["mcast_group"] == "239.1.1.20"
    assert vnis["50001"]["associate_vrf"] is True


def test_evpn_vnis(nxos_config):
    vxlan = ConfigParser(nxos_config).get_vxlan_config(return_json=True)
    evpn = {v["vni"]: v for v in vxlan["evpn_vnis"]}

    assert evpn["10010"]["rd"] == "auto"
    assert evpn["10010"]["route_target_import"] == ["auto"]
    assert evpn["10020"]["route_target_import"] == ["65000:10020"]
    assert evpn["10020"]["route_target_export"] == ["65000:10020"]


def test_vni_mappings(nxos_config):
    vxlan = ConfigParser(nxos_config).get_vxlan_config(return_json=True)

    vlan_map = {m["vlan"]: m["vni"] for m in vxlan["vlan_vni_map"]}
    assert vlan_map == {"10": "10010", "20": "10020"}

    vrf_map = {m["vrf"]: m["vni"] for m in vxlan["vrf_vni_map"]}
    assert vrf_map == {"CUST-A": "50001"}


def test_anycast_gateway(nxos_config):
    vxlan = ConfigParser(nxos_config).get_vxlan_config(return_json=True)
    assert vxlan["anycast_gateway_mac"] == "0000.2222.3333"
    assert vxlan["anycast_gateway_interfaces"] == ["Vlan10"]


def test_vxlan_in_nxos_device_model(nxos_config):
    model = ConfigParser(nxos_config).parse()
    assert model["vxlan"]["nve"]["name"] == "nve1"


def test_non_vxlan_config_returns_empty(ios_switch_config):
    vxlan = ConfigParser(ios_switch_config).get_vxlan_config(return_json=True)
    assert vxlan["nve"] is None
    assert vxlan["evpn_vnis"] == []
