import json
import pathlib
import re

import pytest

from cisco_config_parser import ConfigParser

FIXTURES = pathlib.Path(__file__).parent / "fixtures"


@pytest.fixture(scope="session")
def sda_fe_config():
    return (FIXTURES / "xe_sda_fe.txt").read_text()


def test_named_servers(sda_fe_config):
    aaa = ConfigParser(sda_fe_config).get_aaa_servers(return_json=True)
    servers = {s["name"]: s for s in aaa["servers"]}

    tacacs = servers["lab-tacacs_192.0.2.51"]
    assert tacacs["protocol"] == "tacacs"
    assert tacacs["style"] == "named"
    assert tacacs["address"] == "192.0.2.51"
    assert tacacs["timeout"] == "4"
    assert tacacs["has_key"] is True

    radius = servers["lab-radius_192.0.2.51"]
    assert radius["protocol"] == "radius"
    assert radius["auth_port"] == "1812"
    assert radius["acct_port"] == "1813"
    assert radius["retransmit"] == "3"


def test_server_groups(sda_fe_config):
    aaa = ConfigParser(sda_fe_config).get_aaa_servers(return_json=True)
    groups = {g["name"]: g for g in aaa["groups"]}

    radius_group = groups["lab-radius-group"]
    assert radius_group["protocol"] == "radius"
    assert radius_group["servers"] == [
        "lab-radius_192.0.2.51", "lab-radius_192.0.2.52",
    ]
    assert radius_group["source_interface"] == "Loopback0"

    assert groups["lab-tacacs-group"]["protocol"] == "tacacs"


def test_dynamic_author_and_attributes(sda_fe_config):
    aaa = ConfigParser(sda_fe_config).get_aaa_servers(return_json=True)

    assert aaa["dynamic_author_clients"] == [
        {"client": "192.0.2.51", "has_key": True},
        {"client": "192.0.2.52", "has_key": True},
    ]
    assert "6 on-for-login-auth" in aaa["radius_attributes"]


def test_nxos_legacy_servers_and_group(nxos_config):
    aaa = ConfigParser(nxos_config).get_aaa_servers(return_json=True)

    server = aaa["servers"][0]
    assert server["style"] == "legacy"
    assert server["address"] == "10.10.10.30"
    assert server["has_key"] is True

    group = aaa["groups"][0]
    assert group["name"] == "ISE_TACACS"
    assert group["servers"] == ["10.10.10.30"]
    assert group["source_interface"] == "mgmt0"
    assert group["vrf"] == "management"


def test_no_secrets_in_aaa_output(sda_fe_config, nxos_config):
    for config in (sda_fe_config, nxos_config):
        output = json.dumps(ConfigParser(config).get_aaa_servers(return_json=True))
        assert "REDACTEDREDACTED" not in output


def test_aaa_servers_in_device_model(sda_fe_config):
    model = ConfigParser(sda_fe_config).parse()
    assert len(model["aaa_servers"]["servers"]) == 3
    assert model["parse_errors"] == []
