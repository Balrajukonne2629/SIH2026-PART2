from cisco_config_parser import ConfigParser

BROKEN_CONFIG = """Current configuration : 100 bytes
!
interface Vlan10
 ip address 10.1.1.1 255.255.255.0
 ip access-group ACL-DOES-NOT-EXIST in
!
router bgp 65000
 neighbor 10.0.0.1 remote-as 65001
 neighbor 10.0.0.1 route-map RM-MISSING in
 address-family ipv4 vrf VRF-MISSING
 exit-address-family
!
route-map RM-ORPHAN permit 10
 match ip address prefix-list PL-MISSING
!
"""


def test_undefined_references_detected():
    report = ConfigParser(BROKEN_CONFIG).validate()
    undefined = report["undefined_references"]

    assert [r["name"] for r in undefined["route_map"]] == ["RM-MISSING"]
    assert undefined["route_map"][0]["lines"] == [
        "neighbor 10.0.0.1 route-map RM-MISSING in"
    ]
    assert [r["name"] for r in undefined["prefix_list"]] == ["PL-MISSING"]
    assert [r["name"] for r in undefined["access_list"]] == ["ACL-DOES-NOT-EXIST"]
    assert [r["name"] for r in undefined["vrf"]] == ["VRF-MISSING"]


def test_unused_definitions_detected():
    report = ConfigParser(BROKEN_CONFIG).validate()
    # RM-ORPHAN is defined but nothing references it
    assert report["unused_definitions"]["route_map"] == ["RM-ORPHAN"]


def test_ios_router_fixture_is_consistent(ios_router_config):
    report = ConfigParser(ios_router_config).validate()

    # every reference in the fixture resolves to a definition
    assert report["undefined_references"] == {}

    # the community-lists and numbered ACLs are defined but never applied
    unused = report["unused_definitions"]
    assert set(unused["community_list"]) == {"1", "120", "CL-ANY-65100", "CL-CUSTOMER"}
    assert set(unused["access_list"]) == {"10", "110"}
    # everything that is referenced is not reported
    assert "route_map" not in unused
    assert "prefix_list" not in unused
    assert "vrf" not in unused


def test_nxos_nested_route_map_references_are_not_definitions(nxos_config):
    # NXOS "route-map X in" lines under bgp neighbors start with
    # "route-map" but are references; they must mark the map as used
    report = ConfigParser(nxos_config).validate()
    assert report["undefined_references"] == {}
    assert "route_map" not in report["unused_definitions"]


def test_xr_route_policy_and_prefix_set_references(xr_config):
    report = ConfigParser(xr_config).validate()
    assert report["undefined_references"] == {}

    unused = report["unused_definitions"]
    # RP-CORE-IN/RP-PASS-ALL are used by bgp; PS-RFC1918 by RP-CORE-IN
    assert "route_policy" not in unused
    assert unused["prefix_set"] == ["PS-DEFAULT-ONLY"]
    assert unused["community_set"] == ["CS-CUSTOMER"]


def test_implicit_vrfs_not_flagged(nxos_config):
    # "vrf member management" must not be reported as undefined
    report = ConfigParser(nxos_config).validate()
    undefined_vrfs = [r["name"] for r in report["undefined_references"].get("vrf", [])]
    assert "management" not in undefined_vrfs
