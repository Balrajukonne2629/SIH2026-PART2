# Description: IOS-XR OSPF parser. XR OSPF is fully hierarchical:
# "router ospf <pid>" > "area <n>" > "interface <name>" with per-interface
# settings ("passive enable", "cost N"), plus "vrf <name>" subsections.

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .rtp_xr_rtp_obj import XROSPF, XROSPFArea, XROSPFInterface, XROSPFVrf

ROUTER_OSPF_REGEX = re.compile(r"^router ospf\s+(\S+)")
ROUTER_ID_REGEX = re.compile(r"^router-id\s+(\S+)")
AREA_REGEX = re.compile(r"^area\s+(\S+)")
INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")
PASSIVE_REGEX = re.compile(r"^passive enable")
COST_REGEX = re.compile(r"^cost\s+(\d+)")
VRF_REGEX = re.compile(r"^vrf\s+(\S+)")

__all__ = ["XROSPFConfig"]


def _parse_area(area_node):
    """
    Parse one "area <n>" section with its interface subsections
    :return: XROSPFArea
    """
    area = XROSPFArea(
        area=AREA_REGEX.match(area_node.line).group(1),
        children=area_node.child_lines(),
    )
    for child in area_node.children:
        intf_regex = INTERFACE_REGEX.match(child.line)
        if not intf_regex:
            continue
        interface = XROSPFInterface(
            interface=intf_regex.group(1),
            area=area.area,
            children=child.child_lines(),
        )
        for intf_child in child.children:
            if PASSIVE_REGEX.match(intf_child.line):
                interface.passive = True
            cost_regex = COST_REGEX.match(intf_child.line)
            if cost_regex:
                interface.cost = cost_regex.group(1)
        area.interfaces.append(interface)
    return area


@dataclass
class XROSPFConfig:
    content: str = None

    def _fetch_ospf_config(self, return_json=False):
        """
        Fetch the OSPF configuration from the config file
        :return: list of XROSPF objects (one per process)
        """
        tree = ConfigTree(self.content)
        ospf_processes = []

        for section in tree.find_objects(ROUTER_OSPF_REGEX):
            ospf = XROSPF(
                process_id=ROUTER_OSPF_REGEX.match(section.line).group(1),
                children=section.child_lines(),
            )

            for child in section.children:
                router_id_regex = ROUTER_ID_REGEX.match(child.line)
                if router_id_regex:
                    ospf.router_id = router_id_regex.group(1)
                    continue

                if AREA_REGEX.match(child.line):
                    ospf.areas.append(_parse_area(child))
                    continue

                vrf_regex = VRF_REGEX.match(child.line)
                if vrf_regex:
                    vrf = XROSPFVrf(vrf=vrf_regex.group(1), children=child.child_lines())
                    for vrf_child in child.children:
                        vrf_router_id_regex = ROUTER_ID_REGEX.match(vrf_child.line)
                        if vrf_router_id_regex:
                            vrf.router_id = vrf_router_id_regex.group(1)
                            continue
                        if AREA_REGEX.match(vrf_child.line):
                            vrf.areas.append(_parse_area(vrf_child))
                    ospf.vrfs.append(vrf)

            ospf_processes.append(ospf)

        if return_json:
            return [ospf.to_dict() for ospf in ospf_processes]
        return ospf_processes
