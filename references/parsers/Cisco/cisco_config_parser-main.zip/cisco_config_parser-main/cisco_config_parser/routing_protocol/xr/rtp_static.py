# Description: IOS-XR static route parser. XR static routes live under
# "router static" > "address-family ..." (and "vrf X" > "address-family ...");
# each route line is "<prefix> <next-hop> [options]" where the next hop can
# be an ip, an interface, or an interface followed by an ip.

import re
import ipaddress
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .rtp_xr_rtp_obj import XRStaticRoute

ROUTER_STATIC_REGEX = re.compile(r"^router static$")
ADDRESS_FAMILY_REGEX = re.compile(r"^address-family\s+(\S+.*)")
VRF_REGEX = re.compile(r"^vrf\s+(\S+)")
IP_REGEX = re.compile(r"^\d+\.\d+\.\d+\.\d+$")
PREFIX_REGEX = re.compile(r"^\S+/\d+$")

__all__ = ["XRStaticRouteConfig"]


@dataclass
class XRStaticRouteConfig:
    content: str = None

    def _fetch_static_route_config(self, return_json=False):
        """
        Fetch static route configuration (default + vrf address-families)
        :return: list of XRStaticRoute objects
        """
        tree = ConfigTree(self.content)
        static_routes = []

        for section in tree.find_objects(ROUTER_STATIC_REGEX):
            for child in section.children:
                af_regex = ADDRESS_FAMILY_REGEX.match(child.line)
                if af_regex:
                    static_routes.extend(
                        self._parse_af_routes(child, af_regex.group(1).strip(), vrf="default")
                    )
                    continue

                vrf_regex = VRF_REGEX.match(child.line)
                if vrf_regex:
                    vrf_name = vrf_regex.group(1)
                    for vrf_child in child.children:
                        vrf_af_regex = ADDRESS_FAMILY_REGEX.match(vrf_child.line)
                        if vrf_af_regex:
                            static_routes.extend(
                                self._parse_af_routes(
                                    vrf_child, vrf_af_regex.group(1).strip(), vrf=vrf_name
                                )
                            )

        if return_json:
            return [route.to_dict() for route in static_routes]
        return static_routes

    def _parse_af_routes(self, af_node, af_name, vrf="default"):
        """
        Parse the route lines under one address-family section
        :return: list of XRStaticRoute
        """
        routes = []
        for node in af_node.children:
            if PREFIX_REGEX.match(node.line.split()[0]):
                routes.append(self._parse_route_line(node.line, af_name, vrf))
        return routes

    @staticmethod
    def _parse_route_line(line, af_name, vrf):
        """
        Parse one "<prefix> <next-hop> [options]" line
        :return: XRStaticRoute
        """
        route = XRStaticRoute(vrf=vrf, address_family=af_name, raw=line)

        tokens = line.split()
        route.prefix = tokens.pop(0)

        try:
            network = ipaddress.ip_network(route.prefix, strict=False)
            route.network = str(network.network_address)
            route.mask = str(network.netmask)
        except ValueError:
            pass

        while tokens:
            token = tokens.pop(0)
            if IP_REGEX.match(token) and route.nexthop_ip is None:
                route.nexthop_ip = token
            elif token == "description" and tokens:
                route.description = " ".join(tokens)
                tokens = []
            elif token == "tag" and tokens:
                route.tag = tokens.pop(0)
            elif token.isdigit():
                route.admin_distance = token
            elif route.nexthop_interface is None and route.nexthop_ip is None:
                route.nexthop_interface = token

        return route
