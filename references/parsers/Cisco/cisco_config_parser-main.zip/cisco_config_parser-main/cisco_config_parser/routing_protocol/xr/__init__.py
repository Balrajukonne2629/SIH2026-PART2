from .rtp_static import XRStaticRouteConfig
from .rtp_ospf import XROSPFConfig
from .rtp_bgp import XRBGPConfig
from .rtp_xr_rtp_obj import (
    XRStaticRoute,
    XROSPF, XROSPFArea, XROSPFInterface, XROSPFVrf,
    XRBGP, XRBGPAddressFamily, XRBGPNeighbor, XRBGPNeighborGroup, XRBGPVrf,
)

__all__ = [
    "XRStaticRouteConfig", "XROSPFConfig", "XRBGPConfig",
    "XRStaticRoute",
    "XROSPF", "XROSPFArea", "XROSPFInterface", "XROSPFVrf",
    "XRBGP", "XRBGPAddressFamily", "XRBGPNeighbor",
    "XRBGPNeighborGroup", "XRBGPVrf",
]
