# Description: Dataclass objects returned by the IOS-XR routing-protocol
# parsers. Class names are XR-prefixed so they do not shadow the IOS/NXOS
# objects when the packages are star-imported.

from dataclasses import dataclass, field

from cisco_config_parser.sections.section_obj import DictMixin


@dataclass
class XRStaticRoute(DictMixin):
    vrf: str = "default"
    address_family: str = None      # e.g. "ipv4 unicast"
    prefix: str = None
    network: str = None
    mask: str = None
    nexthop_ip: str = None
    nexthop_interface: str = None
    admin_distance: str = None
    tag: str = None
    description: str = None
    raw: str = None


@dataclass
class XROSPFInterface(DictMixin):
    interface: str = None
    area: str = None
    passive: bool = False
    cost: str = None
    children: list = field(default_factory=list)


@dataclass
class XROSPFArea(DictMixin):
    area: str = None
    interfaces: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class XROSPFVrf(DictMixin):
    vrf: str = None
    router_id: str = None
    areas: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class XROSPF(DictMixin):
    process_id: str = None
    router_id: str = None
    areas: list = field(default_factory=list)
    vrfs: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class XRBGPAddressFamily(DictMixin):
    name: str = None
    networks: list = field(default_factory=list)
    redistribute: list = field(default_factory=list)
    route_policy: dict = field(default_factory=lambda: {"in": None, "out": None})
    children: list = field(default_factory=list)


@dataclass
class XRBGPNeighbor(DictMixin):
    ip: str = None
    vrf: str = "default"
    remote_as: str = None
    description: str = None
    update_source: str = None
    use_neighbor_group: str = None
    address_families: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class XRBGPNeighborGroup(DictMixin):
    name: str = None
    remote_as: str = None
    update_source: str = None
    address_families: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class XRBGPVrf(DictMixin):
    vrf: str = None
    rd: str = None
    address_families: list = field(default_factory=list)
    neighbors: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class XRBGP(DictMixin):
    as_number: str = None
    router_id: str = None
    neighbor_groups: list = field(default_factory=list)
    address_families: list = field(default_factory=list)
    neighbors: list = field(default_factory=list)
    vrfs: list = field(default_factory=list)
    children: list = field(default_factory=list)


__all__ = [
    "XRStaticRoute",
    "XROSPF", "XROSPFArea", "XROSPFInterface", "XROSPFVrf",
    "XRBGP", "XRBGPAddressFamily", "XRBGPNeighbor",
    "XRBGPNeighborGroup", "XRBGPVrf",
]
