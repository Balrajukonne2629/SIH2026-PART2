# Description: NXOS VXLAN/EVPN parser. Correlates the pieces a VXLAN
# fabric leaf is built from: the NVE interface with its member VNIs, the
# evpn section (per-VNI rd / route-targets), vlan-to-vni mappings
# (vn-segment), vrf L3 VNIs and the anycast-gateway configuration.

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from cisco_config_parser.sections.section_obj import DictMixin

NVE_INTERFACE_REGEX = re.compile(r"^interface nve(\d+)")
SOURCE_INTERFACE_REGEX = re.compile(r"^source-interface\s+(\S+)")
HOST_REACHABILITY_REGEX = re.compile(r"^host-reachability protocol\s+(\S+)")
MEMBER_VNI_REGEX = re.compile(r"^member vni\s+(\d+)(\s+associate-vrf)?")
MCAST_GROUP_REGEX = re.compile(r"^mcast-group\s+(\S+)")
INGRESS_REPLICATION_REGEX = re.compile(r"^ingress-replication protocol\s+(\S+)")

EVPN_SECTION_REGEX = re.compile(r"^evpn$")
EVPN_VNI_REGEX = re.compile(r"^vni\s+(\d+)\s+l2")
RD_REGEX = re.compile(r"^rd\s+(\S+)")
RT_REGEX = re.compile(r"^route-target\s+(import|export|both)\s+(\S+)")

VLAN_REGEX = re.compile(r"^vlan\s+(\d+)$")
VN_SEGMENT_REGEX = re.compile(r"^vn-segment\s+(\d+)")
VRF_CONTEXT_REGEX = re.compile(r"^vrf context\s+(\S+)")
VRF_VNI_REGEX = re.compile(r"^vni\s+(\d+)$")

ANYCAST_GW_MAC_REGEX = re.compile(r"^fabric forwarding anycast-gateway-mac\s+(\S+)")
ANYCAST_GW_MODE_REGEX = re.compile(r"^fabric forwarding mode anycast-gateway")
INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")


@dataclass
class NVEVni(DictMixin):
    vni: str = None
    associate_vrf: bool = False
    mcast_group: str = None
    ingress_replication: str = None
    suppress_arp: bool = False
    children: list = field(default_factory=list)


@dataclass
class NVEInterface(DictMixin):
    name: str = None
    source_interface: str = None
    host_reachability: str = None
    vnis: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class EVPNVni(DictMixin):
    vni: str = None
    rd: str = None
    route_target_import: list = field(default_factory=list)
    route_target_export: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class NXOSVxlan(DictMixin):
    nve: NVEInterface = None
    evpn_vnis: list = field(default_factory=list)
    vlan_vni_map: list = field(default_factory=list)      # {vlan, vni}
    vrf_vni_map: list = field(default_factory=list)       # {vrf, vni}
    anycast_gateway_mac: str = None
    anycast_gateway_interfaces: list = field(default_factory=list)


__all__ = ["NXOSVxlanConfig", "NXOSVxlan", "NVEInterface", "NVEVni", "EVPNVni"]


@dataclass
class NXOSVxlanConfig:
    content: str = None

    def _fetch_vxlan_config(self, return_json=False):
        """
        Fetch the VXLAN/EVPN configuration from the config file
        :return: NXOSVxlan object (fields empty when the fabric is not
                 vxlan-enabled)
        """
        tree = ConfigTree(self.content)
        vxlan = NXOSVxlan()

        for node in tree.find_objects(ANYCAST_GW_MAC_REGEX):
            vxlan.anycast_gateway_mac = ANYCAST_GW_MAC_REGEX.match(node.line).group(1)

        for nve_section in tree.find_objects(NVE_INTERFACE_REGEX):
            vxlan.nve = self._parse_nve(nve_section)

        for evpn_section in tree.find_objects(EVPN_SECTION_REGEX):
            for child in evpn_section.children:
                evpn_vni_regex = EVPN_VNI_REGEX.match(child.line)
                if evpn_vni_regex:
                    vxlan.evpn_vnis.append(self._parse_evpn_vni(child, evpn_vni_regex.group(1)))

        for vlan_section in tree.find_objects(VLAN_REGEX):
            vlan_id = VLAN_REGEX.match(vlan_section.line).group(1)
            for child in vlan_section.children:
                vn_segment_regex = VN_SEGMENT_REGEX.match(child.line)
                if vn_segment_regex:
                    vxlan.vlan_vni_map.append({"vlan": vlan_id, "vni": vn_segment_regex.group(1)})

        for vrf_section in tree.find_objects(VRF_CONTEXT_REGEX):
            vrf_name = VRF_CONTEXT_REGEX.match(vrf_section.line).group(1)
            for child in vrf_section.children:
                vrf_vni_regex = VRF_VNI_REGEX.match(child.line)
                if vrf_vni_regex:
                    vxlan.vrf_vni_map.append({"vrf": vrf_name, "vni": vrf_vni_regex.group(1)})

        for intf_section in tree.find_objects(INTERFACE_REGEX):
            if intf_section.find_children(ANYCAST_GW_MODE_REGEX):
                vxlan.anycast_gateway_interfaces.append(
                    INTERFACE_REGEX.match(intf_section.line).group(1)
                )

        if return_json:
            return vxlan.to_dict()
        return vxlan

    @staticmethod
    def _parse_nve(nve_section):
        """
        Parse the "interface nveN" section with its member VNIs
        :return: NVEInterface
        """
        nve = NVEInterface(
            name=INTERFACE_REGEX.match(nve_section.line).group(1),
            children=nve_section.child_lines(),
        )
        for child in nve_section.children:
            source_regex = SOURCE_INTERFACE_REGEX.match(child.line)
            if source_regex:
                nve.source_interface = source_regex.group(1)
                continue

            reachability_regex = HOST_REACHABILITY_REGEX.match(child.line)
            if reachability_regex:
                nve.host_reachability = reachability_regex.group(1)
                continue

            member_regex = MEMBER_VNI_REGEX.match(child.line)
            if member_regex:
                vni = NVEVni(
                    vni=member_regex.group(1),
                    associate_vrf=bool(member_regex.group(2)),
                    children=child.child_lines(),
                )
                for vni_child in child.children:
                    if vni_child.line == "suppress-arp":
                        vni.suppress_arp = True
                    mcast_regex = MCAST_GROUP_REGEX.match(vni_child.line)
                    if mcast_regex:
                        vni.mcast_group = mcast_regex.group(1)
                    ingress_regex = INGRESS_REPLICATION_REGEX.match(vni_child.line)
                    if ingress_regex:
                        vni.ingress_replication = ingress_regex.group(1)
                nve.vnis.append(vni)
        return nve

    @staticmethod
    def _parse_evpn_vni(vni_node, vni_id):
        """
        Parse one "vni N l2" section under evpn
        :return: EVPNVni
        """
        evpn_vni = EVPNVni(vni=vni_id, children=vni_node.child_lines())
        for child in vni_node.children:
            rd_regex = RD_REGEX.match(child.line)
            if rd_regex:
                evpn_vni.rd = rd_regex.group(1)
                continue
            rt_regex = RT_REGEX.match(child.line)
            if rt_regex:
                direction, target = rt_regex.groups()
                if direction in ("import", "both"):
                    evpn_vni.route_target_import.append(target)
                if direction in ("export", "both"):
                    evpn_vni.route_target_export.append(target)
        return evpn_vni
