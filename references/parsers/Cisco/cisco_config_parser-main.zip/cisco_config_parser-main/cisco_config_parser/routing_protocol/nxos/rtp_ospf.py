# Description: NXOS OSPF parser. On NXOS the areas are configured on the
# interfaces ("ip router ospf 1 area 0.0.0.0"), so the interface sections are
# scanned in addition to the "router ospf" section itself.

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .rtp_nxos_rtp_obj import NXOSOSPF, NXOSOSPFVrf

ROUTER_OSPF_REGEX = re.compile(r"^router ospf\s+(\S+)")
ROUTER_ID_REGEX = re.compile(r"^router-id\s+(\S+)")
AUTO_COST_REGEX = re.compile(r"^auto-cost reference-bandwidth\s+(\S+.*)")
VRF_REGEX = re.compile(r"^vrf\s+(\S+)")
INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")
INTF_OSPF_REGEX = re.compile(r"^ip router ospf\s+(\S+)\s+area\s+(\S+)")
INTF_OSPF_PASSIVE_REGEX = re.compile(r"^ip ospf passive-interface")

__all__ = ["NXOSOSPFConfig"]


@dataclass
class NXOSOSPFConfig:
    content: str = None

    def _fetch_ospf_config(self, return_json=False):
        """
        Fetch the OSPF configuration from the config file
        :return: list of NXOSOSPF objects (one per process)
        """
        tree = ConfigTree(self.content)

        # interface participation, grouped by process id
        interfaces_by_process = {}
        for intf_section in tree.find_objects(INTERFACE_REGEX):
            intf_name = INTERFACE_REGEX.match(intf_section.line).group(1)
            for child in intf_section.children:
                ospf_regex = INTF_OSPF_REGEX.match(child.line)
                if not ospf_regex:
                    continue
                process_id, area = ospf_regex.groups()
                passive = bool(intf_section.find_children(INTF_OSPF_PASSIVE_REGEX))
                interfaces_by_process.setdefault(process_id, []).append({
                    "interface": intf_name,
                    "process_id": process_id,
                    "area": area,
                    "passive": passive,
                })

        ospf_processes = []
        for section in tree.find_objects(ROUTER_OSPF_REGEX):
            process_id = ROUTER_OSPF_REGEX.match(section.line).group(1)
            ospf = NXOSOSPF(
                process_id=process_id,
                children=section.child_lines(),
                interfaces=interfaces_by_process.get(process_id, []),
            )

            for child in section.children:
                router_id_regex = ROUTER_ID_REGEX.match(child.line)
                if router_id_regex:
                    ospf.router_id = router_id_regex.group(1)
                    continue

                auto_cost_regex = AUTO_COST_REGEX.match(child.line)
                if auto_cost_regex:
                    ospf.auto_cost = auto_cost_regex.group(1).strip()
                    continue

                vrf_regex = VRF_REGEX.match(child.line)
                if vrf_regex:
                    vrf = NXOSOSPFVrf(
                        vrf=vrf_regex.group(1),
                        children=child.child_lines(),
                    )
                    for vrf_child in child.children:
                        vrf_router_id_regex = ROUTER_ID_REGEX.match(vrf_child.line)
                        if vrf_router_id_regex:
                            vrf.router_id = vrf_router_id_regex.group(1)
                    ospf.vrfs.append(vrf)

            ospf_processes.append(ospf)

        if return_json:
            return [ospf.to_dict() for ospf in ospf_processes]
        return ospf_processes
