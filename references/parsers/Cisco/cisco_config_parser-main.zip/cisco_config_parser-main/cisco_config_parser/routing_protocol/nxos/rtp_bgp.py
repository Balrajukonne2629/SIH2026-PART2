# Description: NXOS BGP parser. NXOS BGP is fully hierarchical: neighbors,
# templates, address-families and vrfs are indented sections under
# "router bgp <asn>", which maps directly onto the ConfigTree.

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .rtp_nxos_rtp_obj import (
    NXOSBGP, NXOSBGPAddressFamily, NXOSBGPNeighbor, NXOSBGPTemplate, NXOSBGPVrf,
)

ROUTER_BGP_REGEX = re.compile(r"^router bgp\s+(\S+)")
ROUTER_ID_REGEX = re.compile(r"^router-id\s+(\S+)")
NEIGHBOR_REGEX = re.compile(r"^neighbor\s+(\S+)")
TEMPLATE_REGEX = re.compile(r"^template peer\s+(\S+)")
VRF_REGEX = re.compile(r"^vrf\s+(\S+)")
ADDRESS_FAMILY_REGEX = re.compile(r"^address-family\s+(\S+.*)")
REMOTE_AS_REGEX = re.compile(r"^remote-as\s+(\S+)")
DESCRIPTION_REGEX = re.compile(r"^description\s+(.*)")
UPDATE_SOURCE_REGEX = re.compile(r"^update-source\s+(\S+)")
INHERIT_PEER_REGEX = re.compile(r"^inherit peer\s+(\S+)")
NETWORK_REGEX = re.compile(r"^network\s+(\S+)")
REDISTRIBUTE_REGEX = re.compile(r"^redistribute\s+(\S+(?:\s+\S+)?)\s+route-map\s+(\S+)")
ROUTE_MAP_DIR_REGEX = re.compile(r"^route-map\s+(\S+)\s+(in|out)$")

__all__ = ["NXOSBGPConfig"]


def _parse_address_family(af_node):
    """
    Parse an address-family section (under the process, a neighbor, a
    template or a vrf)
    :return: NXOSBGPAddressFamily
    """
    af = NXOSBGPAddressFamily(
        name=ADDRESS_FAMILY_REGEX.match(af_node.line).group(1).strip(),
        children=af_node.child_lines(),
    )
    for child in af_node.children:
        network_regex = NETWORK_REGEX.match(child.line)
        if network_regex:
            af.networks.append(network_regex.group(1))
            continue

        redistribute_regex = REDISTRIBUTE_REGEX.match(child.line)
        if redistribute_regex:
            af.redistribute.append({
                "protocol": redistribute_regex.group(1),
                "route_map": redistribute_regex.group(2),
            })
            continue

        route_map_regex = ROUTE_MAP_DIR_REGEX.match(child.line)
        if route_map_regex:
            af.route_map[route_map_regex.group(2)] = route_map_regex.group(1)
    return af


def _parse_neighbor(neighbor_node, vrf="default"):
    """
    Parse a "neighbor <ip>" section
    :return: NXOSBGPNeighbor
    """
    neighbor = NXOSBGPNeighbor(
        ip=NEIGHBOR_REGEX.match(neighbor_node.line).group(1),
        vrf=vrf,
        children=neighbor_node.child_lines(),
    )
    for child in neighbor_node.children:
        for attr, regex in (
            ("remote_as", REMOTE_AS_REGEX),
            ("description", DESCRIPTION_REGEX),
            ("update_source", UPDATE_SOURCE_REGEX),
            ("inherit_peer", INHERIT_PEER_REGEX),
        ):
            found = regex.match(child.line)
            if found:
                setattr(neighbor, attr, found.group(1).strip())

        if ADDRESS_FAMILY_REGEX.match(child.line):
            neighbor.address_families.append(_parse_address_family(child))
    return neighbor


def _parse_template(template_node):
    """
    Parse a "template peer <name>" section
    :return: NXOSBGPTemplate
    """
    template = NXOSBGPTemplate(
        name=TEMPLATE_REGEX.match(template_node.line).group(1),
        children=template_node.child_lines(),
    )
    for child in template_node.children:
        remote_as_regex = REMOTE_AS_REGEX.match(child.line)
        if remote_as_regex:
            template.remote_as = remote_as_regex.group(1)

        update_source_regex = UPDATE_SOURCE_REGEX.match(child.line)
        if update_source_regex:
            template.update_source = update_source_regex.group(1)

        if ADDRESS_FAMILY_REGEX.match(child.line):
            template.address_families.append(_parse_address_family(child))
    return template


@dataclass
class NXOSBGPConfig:
    content: str = None

    def _fetch_bgp_config(self, return_json=False):
        """
        Fetch the BGP configuration from the config file
        :return: list of NXOSBGP objects (one per process)
        """
        tree = ConfigTree(self.content)
        bgp_processes = []

        for section in tree.find_objects(ROUTER_BGP_REGEX):
            bgp = NXOSBGP(
                as_number=ROUTER_BGP_REGEX.match(section.line).group(1),
                children=section.child_lines(),
            )

            for child in section.children:
                router_id_regex = ROUTER_ID_REGEX.match(child.line)
                if router_id_regex:
                    bgp.router_id = router_id_regex.group(1)
                    continue

                if TEMPLATE_REGEX.match(child.line):
                    bgp.templates.append(_parse_template(child))
                    continue

                if ADDRESS_FAMILY_REGEX.match(child.line):
                    bgp.address_families.append(_parse_address_family(child))
                    continue

                if NEIGHBOR_REGEX.match(child.line):
                    bgp.neighbors.append(_parse_neighbor(child))
                    continue

                vrf_regex = VRF_REGEX.match(child.line)
                if vrf_regex:
                    vrf = NXOSBGPVrf(vrf=vrf_regex.group(1), children=child.child_lines())
                    for vrf_child in child.children:
                        vrf_router_id_regex = ROUTER_ID_REGEX.match(vrf_child.line)
                        if vrf_router_id_regex:
                            vrf.router_id = vrf_router_id_regex.group(1)
                            continue
                        if ADDRESS_FAMILY_REGEX.match(vrf_child.line):
                            vrf.address_families.append(_parse_address_family(vrf_child))
                            continue
                        if NEIGHBOR_REGEX.match(vrf_child.line):
                            vrf.neighbors.append(_parse_neighbor(vrf_child, vrf=vrf.vrf))
                    bgp.vrfs.append(vrf)

            bgp_processes.append(bgp)

        if return_json:
            return [bgp.to_dict() for bgp in bgp_processes]
        return bgp_processes
