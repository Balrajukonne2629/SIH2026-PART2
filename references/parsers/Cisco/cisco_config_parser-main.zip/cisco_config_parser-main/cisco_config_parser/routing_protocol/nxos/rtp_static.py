# Description: NXOS static route parser. NXOS static routes live at the top
# level ("ip route 0.0.0.0/0 10.1.1.1") and inside "vrf context" sections;
# prefixes are CIDR and the next hop can be an interface, an ip, or both.

import re
import ipaddress
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .rtp_nxos_rtp_obj import NXOSStaticRoute

STATIC_ROUTE_REGEX = re.compile(r"^ip route\s+(\S+)\s+(.*)")
VRF_CONTEXT_REGEX = re.compile(r"^vrf context\s+(\S+)")
IP_REGEX = re.compile(r"^\d+\.\d+\.\d+\.\d+$")

__all__ = ["NXOSStaticRouteConfig"]


@dataclass
class NXOSStaticRouteConfig:
    content: str = None

    def _fetch_static_route_config(self, return_json=False):
        """
        Fetch static route configuration (global + vrf context routes)
        :param return_json: return the output in json format
        :return: list of NXOSStaticRoute objects
        """
        tree = ConfigTree(self.content)
        static_routes = []

        for node in tree.find_objects(STATIC_ROUTE_REGEX):
            static_routes.append(self._parse_route_line(node.line, vrf="default"))

        for vrf_section in tree.find_objects(VRF_CONTEXT_REGEX):
            vrf_name = VRF_CONTEXT_REGEX.match(vrf_section.line).group(1)
            for child in vrf_section.find_children(STATIC_ROUTE_REGEX):
                static_routes.append(self._parse_route_line(child.line, vrf=vrf_name))

        if return_json:
            return [route.to_dict() for route in static_routes]
        return static_routes

    @staticmethod
    def _parse_route_line(line, vrf="default"):
        """
        Parse one "ip route <prefix> ..." line
        :return: NXOSStaticRoute
        """
        route = NXOSStaticRoute(vrf=vrf, raw=line)

        route_regex = STATIC_ROUTE_REGEX.match(line)
        route.prefix = route_regex.group(1)
        tokens = route_regex.group(2).split()

        try:
            network = ipaddress.ip_network(route.prefix, strict=False)
            route.network = str(network.network_address)
            route.mask = str(network.netmask)
        except ValueError:
            pass

        while tokens:
            token = tokens.pop(0)
            if IP_REGEX.match(token) and route.nexthop_ip is None:
                route.nexthop_ip = token
            elif token == "name" and tokens:
                route.name = tokens.pop(0)
            elif token == "track" and tokens:
                route.track = tokens.pop(0)
            elif token == "tag" and tokens:
                route.tag = tokens.pop(0)
            elif token.isdigit():
                route.admin_distance = token
            elif route.nexthop_interface is None and route.nexthop_ip is None:
                # first non-keyword token that is not an ip: egress interface
                route.nexthop_interface = token

        return route
