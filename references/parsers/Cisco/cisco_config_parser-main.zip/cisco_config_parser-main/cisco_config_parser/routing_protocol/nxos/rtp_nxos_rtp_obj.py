# Description: Dataclass objects returned by the NXOS routing-protocol
# parsers. Class names are NXOS-prefixed so they do not shadow the IOS
# objects when both packages are star-imported.

from dataclasses import dataclass, field

from cisco_config_parser.sections.section_obj import DictMixin


@dataclass
class NXOSStaticRoute(DictMixin):
    vrf: str = "default"
    prefix: str = None              # e.g. 10.50.0.0/16
    network: str = None
    mask: str = None
    nexthop_ip: str = None
    nexthop_interface: str = None
    name: str = None
    admin_distance: str = None
    track: str = None
    tag: str = None
    raw: str = None


@dataclass
class NXOSOSPFVrf(DictMixin):
    vrf: str = None
    router_id: str = None
    children: list = field(default_factory=list)


@dataclass
class NXOSOSPF(DictMixin):
    process_id: str = None
    router_id: str = None
    auto_cost: str = None
    interfaces: list = field(default_factory=list)     # {interface, area, process_id, passive}
    vrfs: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class NXOSBGPAddressFamily(DictMixin):
    name: str = None                # e.g. "ipv4 unicast"
    networks: list = field(default_factory=list)
    redistribute: list = field(default_factory=list)   # {protocol, route_map}
    route_map: dict = field(default_factory=lambda: {"in": None, "out": None})
    children: list = field(default_factory=list)


@dataclass
class NXOSBGPNeighbor(DictMixin):
    ip: str = None
    vrf: str = "default"
    remote_as: str = None
    description: str = None
    update_source: str = None
    inherit_peer: str = None
    address_families: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class NXOSBGPTemplate(DictMixin):
    name: str = None
    remote_as: str = None
    update_source: str = None
    address_families: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class NXOSBGPVrf(DictMixin):
    vrf: str = None
    router_id: str = None
    address_families: list = field(default_factory=list)
    neighbors: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class NXOSBGP(DictMixin):
    as_number: str = None
    router_id: str = None
    templates: list = field(default_factory=list)
    address_families: list = field(default_factory=list)
    neighbors: list = field(default_factory=list)
    vrfs: list = field(default_factory=list)
    children: list = field(default_factory=list)


__all__ = [
    "NXOSStaticRoute",
    "NXOSOSPF", "NXOSOSPFVrf",
    "NXOSBGP", "NXOSBGPAddressFamily", "NXOSBGPNeighbor",
    "NXOSBGPTemplate", "NXOSBGPVrf",
]
