from .rtp_static import NXOSStaticRouteConfig
from .rtp_ospf import NXOSOSPFConfig
from .rtp_bgp import NXOSBGPConfig
from .rtp_vxlan import NXOSVxlanConfig, NXOSVxlan, NVEInterface, NVEVni, EVPNVni
from .rtp_nxos_rtp_obj import (
    NXOSStaticRoute,
    NXOSOSPF, NXOSOSPFVrf,
    NXOSBGP, NXOSBGPAddressFamily, NXOSBGPNeighbor, NXOSBGPTemplate, NXOSBGPVrf,
)

__all__ = [
    "NXOSStaticRouteConfig", "NXOSOSPFConfig", "NXOSBGPConfig",
    "NXOSVxlanConfig", "NXOSVxlan", "NVEInterface", "NVEVni", "EVPNVni",
    "NXOSStaticRoute",
    "NXOSOSPF", "NXOSOSPFVrf",
    "NXOSBGP", "NXOSBGPAddressFamily", "NXOSBGPNeighbor",
    "NXOSBGPTemplate", "NXOSBGPVrf",
]
