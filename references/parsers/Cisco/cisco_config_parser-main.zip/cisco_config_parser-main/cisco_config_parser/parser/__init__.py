from .parser import Parser




class ConfigParser(Parser):
    def __init__(self, _content, platform=None):
        super().__init__(_content, platform=platform)


    def parse(self, include_raw_tree=False):
        """
        Parse the whole running config into one JSON-able dictionary:
        platform, hostname, identity (users/aaa/snmp/ntp/logging/lines),
        vrfs, vlans, interfaces, access-lists, prefix-lists, route-maps,
        routing (static/ospf/eigrp/bgp) and banner.

        Sections not implemented for the platform are listed under
        "unsupported"; parser failures under "parse_errors".
        :param include_raw_tree: also attach the full config hierarchy
                                 under "config_tree"
        :return: dict
        """
        return self._build_device_model(include_raw_tree=include_raw_tree)


    def get_static_config(self, return_json=False):
        """
        Get the static routes from the config file
        :return: list of static route objects
        """
        return self._get_static_config(return_json=return_json)


    def get_ospf_config(self, return_json=False):
        """
        Get the ospf configuration from the config file
        :return: list of ospf objects or json
        """
        return self._get_ospf_config(return_json=return_json)


    def get_eigrp_config(self, return_json=False):
        """
        Get the eigrp configuration from the config file
        :return: list of eigrp objects or json
        """
        return self._get_eigrp_config(return_json=return_json)


    def get_bgp_config(self, return_json=False):
        """
        Get the eigrp configuration from the config file
        :return: list of eigrp objects or json
        """
        return self._get_bgp_config(return_json=return_json)



    def get_netflow(self, return_json=False):
        """
        Get the NetFlow configuration: flow records (match/collect),
        exporters (destination/source/port), monitors (record +
        exporters + cache), XR sampler-maps and the per-interface
        attachments on IOS-XE and XR
        :return: NetflowConfig object or json
        """
        return self._get_netflow(return_json=return_json)


    def get_aaa_servers(self, return_json=False):
        """
        Get the TACACS+/RADIUS server configuration: named (IOS-XE
        "tacacs server X") and legacy ("tacacs-server host X") servers,
        aaa server groups with source-interface/vrf, CoA dynamic-author
        clients and radius-server attribute tuning.
        Key hashes are reported as has_key booleans, never stored.
        :return: AAAServersConfig object or json
        """
        return self._get_aaa_servers(return_json=return_json)


    def get_trustsec(self, return_json=False):
        """
        Get the TrustSec (cts) configuration: authorization list, sxp
        peering, role-based enforcement, ip-to-sgt maps, sgacl
        permissions and per-interface cts manual blocks.
        Secrets (sxp password, key hashes) are never stored.
        :return: CTSConfig object or json
        """
        return self._get_trustsec(return_json=return_json)


    def get_lisp_config(self, return_json=False):
        """
        Get the LISP (router lisp) configuration for SD-Access fabric
        nodes: domain-id, locator-sets, services, instance-ids with
        dynamic-eids and database-mappings
        :return: LISPRouter object, json, or None when absent
        """
        return self._get_lisp_config(return_json=return_json)


    def get_vpc_config(self, return_json=False):
        """
        Get the NXOS vPC configuration: vpc domain settings (priorities,
        peer-keepalive, peer-gateway, auto-recovery, ...), the peer-link
        port-channel and every vpc-attached port-channel
        :return: VPCDomain object, json, or None when absent
        """
        return self._get_vpc_config(return_json=return_json)


    def get_vxlan_config(self, return_json=False):
        """
        Get the NXOS VXLAN/EVPN configuration: nve interface with member
        VNIs, evpn per-VNI rd/route-targets, vlan-to-vni and vrf-to-vni
        mappings, anycast gateway mac + interfaces
        :return: NXOSVxlan object or json
        """
        return self._get_vxlan_config(return_json=return_json)


    def get_fhrp_groups(self, return_json=False):
        """
        Get the first-hop redundancy groups (HSRP/VRRP) per interface:
        protocol, group, vip, priority, preempt, version, track
        :return: list of FHRPGroup objects or json
        """
        return self._get_fhrp_groups(return_json=return_json)


    def get_port_channels(self, return_json=False):
        """
        Get the port-channels / bundles with their member interfaces,
        bundling protocol (lacp/pagp/static) and NXOS vpc id
        :return: list of PortChannel objects or json
        """
        return self._get_port_channels(return_json=return_json)


    def validate(self):
        """
        Cross-reference validation: policy objects (route-maps,
        prefix-lists/sets, community-lists/sets, ACLs, route-policies,
        VRFs) that are referenced but never defined, and defined but
        never referenced.

        "Unused" is a best-effort audit hint - an object may be used by
        a feature this library does not scan yet.
        :return: dict with "undefined_references" and "unused_definitions"
        """
        return self._validate_references()


    def get_access_lists(self, return_json=False):
        """
        Get the access-lists (named + numbered, standard + extended)
        :return: list of AccessList objects or json
        """
        return self._get_access_lists(return_json=return_json)


    def get_prefix_lists(self, return_json=False):
        """
        Get the prefix-lists, grouped by name
        :return: list of PrefixList objects or json
        """
        return self._get_prefix_lists(return_json=return_json)


    def get_prefix_sets(self, return_json=False):
        """
        Get the IOS-XR prefix-sets
        :return: list of PrefixSet objects or json
        """
        return self._get_prefix_sets(return_json=return_json)


    def get_community_lists(self, return_json=False):
        """
        Get the bgp community-lists (standard/expanded, named/numbered),
        grouped by name
        :return: list of CommunityList objects or json
        """
        return self._get_community_lists(return_json=return_json)


    def get_community_sets(self, return_json=False):
        """
        Get the IOS-XR community-sets
        :return: list of CommunitySet objects or json
        """
        return self._get_community_sets(return_json=return_json)


    def get_extcommunity_sets(self, return_json=False):
        """
        Get the IOS-XR extcommunity-sets (route-target / site-of-origin)
        :return: list of CommunitySet objects or json
        """
        return self._get_extcommunity_sets(return_json=return_json)


    def get_route_maps(self, return_json=False):
        """
        Get the route-maps, one clause per permit/deny sequence
        :return: list of RouteMap objects or json
        """
        return self._get_route_maps(return_json=return_json)


    def get_route_policies(self, return_json=False):
        """
        Get the IOS-XR route-policies (raw RPL bodies)
        :return: list of RoutePolicy objects or json
        """
        return self._get_route_policies(return_json=return_json)


    def get_vrfs(self, return_json=False):
        """
        Get the vrf definitions (rd, route-targets, address-families)
        :return: list of VRF objects or json
        """
        return self._get_vrfs(return_json=return_json)


    def get_device_identity(self, return_json=False):
        """
        Get device identity and management-plane config:
        hostname, version, domain, users, aaa, snmp, ntp, logging, line vty/con
        :return: DeviceIdentity object or json
        """
        return self._get_device_identity(return_json=return_json)


    def get_vlan_info(self):
        """
        Get the vlan information from the config file
        :return: list of vlan objects
        """
        return self._get_vlan_info()

    def get_banner(self):
        """
        Get the banner from the config file
        :return: banner object
        """
        return self._get_banner()

    def get_parent_child(self, **kwargs):
        """
        Get parent child from the config file
        :param kwargs: parent_regex, child_regex, return_json
        :return: list of parent child objects
        """
        parent_regex = kwargs.get("parent_regex", None)
        child_regex = kwargs.get("child_regex", None)
        return_json = kwargs.get("return_json", False)
        kwargs = {"parent_regex": parent_regex, "child_regex": child_regex, "return_json": return_json}

        return self._get_parent_child(**kwargs)


    def get_subnet_and_usage(self, include_subnet_count=False):
        """
        Fetch the subnet usage from the config file
        return: dictionary of subnet usage
        """
        return self._get_subnet_and_usage(include_subnet_count=include_subnet_count)


    def get_l3_interfaces(self, **kwargs):
        """
        -Description: \n
        Get L3 interfaces from the config file\n
        you can pass custom regex with custom name\n
        i.e. obj.get_l3_interfaces(ip_pim="ip pim.*")\n
        ,or you can pass return_json=True to get the output in json format
        :param: custom regex, return_json
        :return: list of L3 interface objects
        """

        return self._get_l3_interfaces(**kwargs)

    def get_l3_interface_details(self):
        """
        Get the L3 interface details
        :return: dictionary of L3 interface details
        """
        return self._get_l3_interface_details()

    def get_l2_access_interfaces(self, **kwargs):
        """
        Get L2 access interfaces from the config file
        :return: list of L2 access interface objects
        """
        return self._get_l2_access_interfaces(**kwargs)

    def get_l2_access_interface_details(self):
        """
        Get the L2 interface details
        :return: dictionary of L2 interface details
        """
        return self._get_l2_access_interface_details()

    def get_l2_trunk_interfaces(self, **kwargs):
        """
        Get L2 trunk interfaces from the config file
        :return: list of L2 trunk interface objects
        """
        return self._get_l2_trunk_interfaces(**kwargs)

    def get_l2_trunk_interface_details(self):
        """
        Get the L2 interface details
        :return: dictionary of L2 interface details
        """
        return self._get_l2_trunk_interface_details()




from cisco_config_parser.old_version.utils import OldParser

class ConfigParserOld(OldParser):
    def find_parent_child(self, regex):
        return self._parent_child_relationship(regex)

    def ios_get_banner_login(self):
        return self._ios_fetch_banner_login()

    def ios_get_switchport(self, **kwargs):
        return self._ios_fetch_switchport(**kwargs)

    def ios_get_routed_port(self):
        return self._ios_fetch_routed_port()

    def ios_get_svi_objects(self):
        return self._ios_fetch_svi_objects()

    def nxos_get_vlan_info(self):
        return self._nxos_fetch_vlan_info()

    def nxos_get_vlan(self):
        return self._nxos_fetch_vlan_list()

    def nxos_get_l3_int(self):
        return self._nxos_fetch_l3_int()

    def nxos_get_routing_protocol(self):
        return self._nxos_fetch_routing_protocol()






