from cisco_config_parser.layer3_interface import L3InterfaceParser
from cisco_config_parser.layer2_interface import L2InterfaceParser
from cisco_config_parser.parent_child import ParentChildParser
from cisco_config_parser.global_search import GlobalParser
from cisco_config_parser.routing_protocol import *
from cisco_config_parser.sections import (
    ACLParser, PrefixListParser, RouteMapParser, CommunityListParser,
    VRFParser, DeviceIdentityParser, CrossReferenceValidator,
    FHRPParser, PortChannelParser, TrustSecParser, LISPParser, VPCParser,
    AAAServersParser, NetflowParser,
)

from cisco_config_parser.parser_regex.ios_regex import *


# Normalized platform names. Exact alias lookup instead of substring matching,
# so "IOS-XR" does not accidentally match "ios".
PLATFORM_ALIASES = {
    "ios": "IOS",
    "iosxe": "IOS",
    "ios-xe": "IOS",
    "ios xe": "IOS",
    "nxos": "NXOS",
    "nx-os": "NXOS",
    "xr": "XR",
    "iosxr": "XR",
    "ios-xr": "XR",
    "ios xr": "XR",
}


class Parser:
    # feature -> platform -> parser class. Platforms without an implementation
    # are simply absent and raise NotImplementedError at call time.
    _ROUTING_PROTOCOL_PARSERS = {
        "static": {"IOS": IOSStaticRouteConfig, "NXOS": NXOSStaticRouteConfig, "XR": XRStaticRouteConfig},
        "ospf": {"IOS": IOSOSPFConfig, "NXOS": NXOSOSPFConfig, "XR": XROSPFConfig},
        "eigrp": {"IOS": IOSEIGRPConfig},
        "bgp": {"IOS": IOSBGPConfig, "NXOS": NXOSBGPConfig, "XR": XRBGPConfig},
    }

    def __init__(self, _content, platform=None):
        self._content = _content
        self._platform = self._normalize_platform(platform)
        self._l3_parser_obj = L3InterfaceParser(self._content)
        self._l2_parser_obj = L2InterfaceParser(self._content)
        self._parent_child_parser_obj = ParentChildParser(self._content)
        self._global_parser_obj = GlobalParser(self._content)

    @staticmethod
    def _normalize_platform(platform):
        """
        Normalize a user-supplied platform string to IOS/NXOS/XR
        :return: string or None
        """
        if platform is None:
            return None

        normalized = PLATFORM_ALIASES.get(platform.lower().strip())
        if normalized is None:
            raise ValueError(
                f"Unknown platform {platform!r}. "
                f"Supported values: IOS, IOS-XE, NXOS, XR/IOS-XR"
            )
        return normalized

    def determine_platform(self):
        """
        Determine the platform of the device
        IOS, NXOS, IOSXR
        :return: string - "IOS", "NXOS" or "XR"
        - IOS running_config will have "Current configuration : <digts> bytes" at the beginning
        - NXOS running_config will have "!Command: show running-config" at the beginning or we can look for "feature" keyword
        - IOSXR running_config will have "!! IOS XR Configuration 6.2.3" at the beginning or we can look for "prefix-set" or "route-policy" keyword
        """
        if self._platform:
            return self._platform

        if IOS_PLATFORM_REGEX_1.search(self._content):
            return "IOS"

        elif NXOS_PLATFORM_REGEX_1.search(self._content) or NXOS_PLATFORM_REGEX_2.search(self._content):
            return "NXOS"

        elif XR_PLATFORM_REGEX_1.search(self._content) \
                or XR_PLATFORM_REGEX_2.search(self._content) \
                or XR_PLATFORM_REGEX_3.search(self._content):
            return "XR"

        raise ValueError("""
            ------------------------------------------------------------------------------------------------------
                                Not able to determine the platform of the device.
            Please pass the platform='IOS' or platform='NXOS' or platform='XR' as an argument to the Parser class
            ------------------------------------------------------------------------------------------------------
            """)

    def _resolve_routing_parser(self, feature):
        """
        Resolve the parser class for a routing-protocol feature on this platform
        :param feature: "static", "ospf", "eigrp" or "bgp"
        :return: parser class
        """
        platform = self.determine_platform()
        parser_cls = self._ROUTING_PROTOCOL_PARSERS[feature].get(platform)
        if parser_cls is None:
            supported = ", ".join(sorted(self._ROUTING_PROTOCOL_PARSERS[feature]))
            raise NotImplementedError(
                f"{feature.upper()} parsing is not implemented for platform {platform}. "
                f"Currently supported platforms for {feature}: {supported}"
            )
        return parser_cls

    def _get_static_config(self, return_json=False):
        """
        Get the static routes from the config file
        :return: list of static route objects
        """
        parser_cls = self._resolve_routing_parser("static")
        return parser_cls(self._content)._fetch_static_route_config(return_json=return_json)


    def _get_ospf_config(self, return_json=False):
        """
        Get the ospf configuration from the config file
        :return: list of ospf objects
        """
        parser_cls = self._resolve_routing_parser("ospf")
        return parser_cls(self._content)._fetch_ospf_config(return_json=return_json)


    def _get_eigrp_config(self, return_json=False):
        """
        Get the eigrp configuration from the config file
        :return: list of eigrp objects
        """
        parser_cls = self._resolve_routing_parser("eigrp")
        return parser_cls(self._content)._fetch_eigrp_config(return_json=return_json)


    def _get_bgp_config(self, return_json=False):
        """
        Get the bgp configuration from the config file
        :return: list of bgp objects
        """
        parser_cls = self._resolve_routing_parser("bgp")
        return parser_cls(self._content)._fetch_bgp_config(return_json=return_json)




    def _build_device_model(self, include_raw_tree=False):
        """
        Build one JSON-able dictionary describing the whole device.
        Sections that are not implemented for the detected platform are set
        to None and listed under "unsupported"; unexpected parser failures
        are captured under "parse_errors" instead of aborting the model.
        :return: dict
        """
        platform = self.determine_platform()
        model = {
            "platform": platform,
            "hostname": None,
            "identity": None,
            "vrfs": None,
            "vlans": None,
            "l3_interfaces": None,
            "l2_access_interfaces": None,
            "l2_trunk_interfaces": None,
            "access_lists": None,
            "prefix_lists": None,
            "community_lists": None,
            "route_maps": None,
            "fhrp_groups": None,
            "port_channels": None,
            "trustsec": None,
            "lisp": None,
            "aaa_servers": None,
            "netflow": None,
            "routing": {"static": None, "ospf": None, "eigrp": None, "bgp": None},
            "banner": None,
            "unsupported": [],
            "parse_errors": [],
        }

        def collect(key, fetch, target=model):
            try:
                target[key] = fetch()
            except NotImplementedError:
                model["unsupported"].append(key)
            except Exception as exc:  # keep the rest of the model usable
                model["parse_errors"].append({"section": key, "error": str(exc)})

        collect("identity", lambda: self._get_device_identity(return_json=True))
        collect("vrfs", lambda: self._get_vrfs(return_json=True))
        collect("vlans", self._get_vlan_model)
        collect("l3_interfaces", lambda: self._get_l3_interfaces(return_json=True))
        collect("l2_access_interfaces", lambda: self._get_l2_access_interfaces(return_json=True))
        collect("l2_trunk_interfaces", lambda: self._get_l2_trunk_interfaces(return_json=True))
        collect("access_lists", lambda: self._get_access_lists(return_json=True))
        collect("prefix_lists", lambda: self._get_prefix_lists(return_json=True))
        collect("community_lists", lambda: self._get_community_lists(return_json=True))
        collect("route_maps", lambda: self._get_route_maps(return_json=True))
        collect("fhrp_groups", lambda: self._get_fhrp_groups(return_json=True))
        collect("port_channels", lambda: self._get_port_channels(return_json=True))
        collect("trustsec", lambda: self._get_trustsec(return_json=True))
        collect("lisp", lambda: self._get_lisp_config(return_json=True))
        collect("aaa_servers", lambda: self._get_aaa_servers(return_json=True))
        collect("netflow", lambda: self._get_netflow(return_json=True))
        collect("banner", lambda: self._get_banner().banner)

        routing = model["routing"]
        collect("static", lambda: self._get_static_config(return_json=True), target=routing)
        collect("ospf", lambda: self._get_ospf_config(return_json=True), target=routing)
        collect("eigrp", lambda: self._get_eigrp_config(return_json=True), target=routing)
        collect("bgp", lambda: self._get_bgp_config(return_json=True), target=routing)

        if platform == "NXOS":
            collect("vxlan", lambda: self._get_vxlan_config(return_json=True))
            collect("vpc", lambda: self._get_vpc_config(return_json=True))

        if platform == "XR":
            collect("prefix_sets", lambda: self._get_prefix_sets(return_json=True))
            collect("community_sets", lambda: self._get_community_sets(return_json=True))
            collect("extcommunity_sets", lambda: self._get_extcommunity_sets(return_json=True))
            collect("route_policies", lambda: self._get_route_policies(return_json=True))

        if model["identity"]:
            model["hostname"] = model["identity"].get("hostname")

        if include_raw_tree:
            from cisco_config_parser.config_tree import ConfigTree
            collect("config_tree", lambda: ConfigTree(self._content).to_dict())

        return model

    def _get_vlan_model(self):
        """
        VLANs as plain dictionaries with the id and name pulled out
        :return: list of dict
        """
        vlans = []
        for vlan_obj in self._get_vlan_info():
            vlan_id = vlan_obj.vlan.replace("vlan", "").strip() if vlan_obj.vlan else None
            name = None
            for child in vlan_obj.children or []:
                if child.startswith("name "):
                    name = child.replace("name ", "", 1).strip()
            vlans.append({"id": vlan_id, "name": name, "children": vlan_obj.children})
        return vlans

    def _get_access_lists(self, return_json=False):
        """
        Get the access-lists from the config file
        :return: list of AccessList objects
        """
        return ACLParser(self._content)._fetch_access_lists(return_json=return_json)


    def _get_prefix_lists(self, return_json=False):
        """
        Get the prefix-lists from the config file
        :return: list of PrefixList objects
        """
        return PrefixListParser(self._content)._fetch_prefix_lists(return_json=return_json)


    def _get_prefix_sets(self, return_json=False):
        """
        Get the IOS-XR prefix-sets from the config file
        :return: list of PrefixSet objects
        """
        return PrefixListParser(self._content)._fetch_prefix_sets(return_json=return_json)


    def _get_community_lists(self, return_json=False):
        """
        Get the bgp community-lists from the config file
        :return: list of CommunityList objects
        """
        return CommunityListParser(self._content)._fetch_community_lists(return_json=return_json)


    def _get_community_sets(self, return_json=False):
        """
        Get the IOS-XR community-sets from the config file
        :return: list of CommunitySet objects
        """
        return CommunityListParser(self._content)._fetch_community_sets(return_json=return_json)


    def _get_extcommunity_sets(self, return_json=False):
        """
        Get the IOS-XR extcommunity-sets (rt/soo) from the config file
        :return: list of CommunitySet objects
        """
        return CommunityListParser(self._content)._fetch_extcommunity_sets(return_json=return_json)


    def _get_route_maps(self, return_json=False):
        """
        Get the route-maps from the config file
        :return: list of RouteMap objects
        """
        return RouteMapParser(self._content)._fetch_route_maps(return_json=return_json)


    def _get_route_policies(self, return_json=False):
        """
        Get the IOS-XR route-policies from the config file
        :return: list of RoutePolicy objects
        """
        return RouteMapParser(self._content)._fetch_route_policies(return_json=return_json)


    def _get_vrfs(self, return_json=False):
        """
        Get the vrf definitions from the config file
        :return: list of VRF objects
        """
        return VRFParser(self._content)._fetch_vrfs(return_json=return_json)


    def _get_netflow(self, return_json=False):
        """
        Get the NetFlow configuration from the config file
        :return: NetflowConfig object
        """
        return NetflowParser(self._content)._fetch_netflow(return_json=return_json)


    def _get_aaa_servers(self, return_json=False):
        """
        Get the TACACS+/RADIUS server configuration from the config file
        :return: AAAServersConfig object
        """
        return AAAServersParser(self._content)._fetch_aaa_servers(return_json=return_json)


    def _get_trustsec(self, return_json=False):
        """
        Get the TrustSec (cts) configuration from the config file
        :return: CTSConfig object
        """
        return TrustSecParser(self._content)._fetch_trustsec(return_json=return_json)


    def _get_lisp_config(self, return_json=False):
        """
        Get the LISP (router lisp) configuration from the config file
        :return: LISPRouter object or None
        """
        return LISPParser(self._content)._fetch_lisp_config(return_json=return_json)


    def _get_vpc_config(self, return_json=False):
        """
        Get the NXOS vPC configuration (vpc domain + peer-link and
        vpc-attached port-channels)
        :return: VPCDomain object or None
        """
        return VPCParser(self._content)._fetch_vpc_config(return_json=return_json)


    def _get_vxlan_config(self, return_json=False):
        """
        Get the NXOS VXLAN/EVPN configuration (nve, evpn vnis, vlan/vrf
        vni maps, anycast gateway)
        :return: NXOSVxlan object
        """
        return NXOSVxlanConfig(self._content)._fetch_vxlan_config(return_json=return_json)


    def _get_fhrp_groups(self, return_json=False):
        """
        Get the HSRP/VRRP groups from the config file
        :return: list of FHRPGroup objects
        """
        return FHRPParser(self._content)._fetch_fhrp_groups(return_json=return_json)


    def _get_port_channels(self, return_json=False):
        """
        Get the port-channels / bundles from the config file
        :return: list of PortChannel objects
        """
        return PortChannelParser(self._content)._fetch_port_channels(return_json=return_json)


    def _validate_references(self):
        """
        Cross-reference validation report
        :return: dict of undefined_references / unused_definitions
        """
        return CrossReferenceValidator(self._content)._validate()


    def _get_device_identity(self, return_json=False):
        """
        Get the device identity (hostname, users, aaa, snmp, ntp, logging, lines)
        :return: DeviceIdentity object
        """
        return DeviceIdentityParser(self._content)._fetch_device_identity(return_json=return_json)


    def _get_vlan_info(self):
        """
        Get the vlan information from the config file
        :return: list of vlan objects
        """
        return self._global_parser_obj._fetch_vlan_info()


    def _get_banner(self):
        """
        Get the banner from the config file
        :return: banner object
        """
        return self._global_parser_obj._fetch_banner()

    def _get_parent_child(self, **kwargs):
        """
        Get parent child from the config file
        :param kwargs: parent_regex, child_regex
        :param kwargs: return_json: bool - Default False
        :return: list of parent child objects
        """
        return self._parent_child_parser_obj._fetch_parent_child(**kwargs)


    def _get_subnet_and_usage(self, include_subnet_count=False):
        """
        Fetch the subnet usage from the config file
        return: dictionary of subnet usage and subnet count
        """

        return self._l3_parser_obj._fetch_subnet_and_usage(include_subnet_count=include_subnet_count)


    def _get_l3_interfaces(self, **kwargs):
        """
        Get L3 interfaces from the config file
        :return: list of L3 interface objects
        """
        return self._l3_parser_obj._fetch_l3_interfaces(**kwargs)

    def _get_l3_interface_details(self):
        """
        Get the L3 interface details
        :return: dictionary of L3 interface details
        """
        l3_interfaces = self._get_l3_interfaces()

        if not l3_interfaces:
            return {}  # Return an empty dictionary if no interfaces are found

        return {interface.name: interface.children for interface in l3_interfaces}

    def _get_l2_access_interfaces(self, **kwargs):
        """
        Get L2 interfaces from the config file
        :return: list of L2 interface objects
        """
        return self._l2_parser_obj._fetch_l2_access_interfaces(**kwargs)

    def _get_l2_access_interface_details(self):
        """
        Get the L2 interface details
        :return: dictionary of L2 interface details
        """
        l2_access_interfaces = self._get_l2_access_interfaces()

        if not l2_access_interfaces:
            return {}

        return {interface.name: interface.children for interface in l2_access_interfaces}


    def _get_l2_trunk_interfaces(self, **kwargs):
        """
        Get L2 interfaces from the config file
        :return: list of L2 interface objects
        """
        return self._l2_parser_obj._fetch_l2_trunk_interfaces(**kwargs)

    def _get_l2_trunk_interface_details(self):
        """
        Get the L2 interface details
        :return: dictionary of L2 interface details
        """
        l2_trunk_interfaces = self._get_l2_trunk_interfaces()

        if not l2_trunk_interfaces:
            return {}

        return {interface.name: interface.children for interface in l2_trunk_interfaces}




