import re

from .global_separator import GlobalSeparator
from dataclasses import dataclass
from cisco_config_parser.parser_regex import *
from .global_obj import BannerObj, VLANObj





@dataclass
class GlobalParser:
    content: str = None

    _BANNER_START_REGEX = re.compile(r"^banner\s+\S+\s+(.*)$")

    def _fetch_banner(self, **kwargs):
        """
        Collect banner blocks. The delimiter is whatever character (or ^C)
        follows the banner type, so '#', '$' and same-line-closing banners
        all terminate correctly instead of swallowing the rest of the config.
        """
        banner_obj = BannerObj()
        banner_lines = []
        lines = self.content.splitlines()

        index = 0
        total = len(lines)
        while index < total:
            line = lines[index].strip()
            index += 1
            if not line.startswith("banner "):
                continue

            banner_lines.append(line)
            start_regex = self._BANNER_START_REGEX.match(line)
            remainder = start_regex.group(1) if start_regex else ""
            delimiter = "^C" if remainder.startswith("^C") else remainder[:1] or "^C"

            # banner opened and closed on the same line
            if delimiter in remainder[len(delimiter):]:
                continue

            while index < total:
                body_line = lines[index].strip()
                index += 1
                banner_lines.append(body_line)
                if delimiter in body_line:
                    break

        banner_obj.banner = banner_lines
        return banner_obj


    def _fetch_vlan_info(self, **kwargs):
        """
        Fetch the vlan information from the config file
        :return: list of vlan objects
        """
        global_separator = GlobalSeparator(self.content)
        vlan_sections = global_separator._find_vlan_section()
        vlan_objects = []
        for vlan_section in vlan_sections:
            vlan_obj = VLANObj()

            vlan_regex = VLAN_REGEX.search(vlan_section)
            if vlan_regex:
                vlan_obj.vlan = vlan_regex.group()

            vlan_obj.children = [
                line.strip() for line in vlan_section.splitlines()
                if line.strip() and not line.strip().startswith("vlan")
            ]
            vlan_objects.append(vlan_obj)

        return vlan_objects


