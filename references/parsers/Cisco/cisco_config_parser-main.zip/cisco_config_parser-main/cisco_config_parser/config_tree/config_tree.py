# Description: Generic indentation-based hierarchy parser for Cisco configs.
# The whole running-config is parsed once into a tree of ConfigNode objects;
# feature parsers select the sections they care about instead of re-scanning
# the raw text with their own separators.

import re
from dataclasses import dataclass, field


BANNER_REGEX = re.compile(r"^banner\s+\S+\s+(\S+)")


@dataclass
class ConfigNode:
    """
    One line of configuration plus everything indented underneath it.
    """
    line: str = ""
    depth: int = 0
    children: list = field(default_factory=list)

    def find_children(self, regex):
        """
        Direct children whose line matches the regex
        :param regex: str or compiled pattern
        :return: list of ConfigNode
        """
        pattern = re.compile(regex) if isinstance(regex, str) else regex
        return [child for child in self.children if pattern.search(child.line)]

    def find_all(self, regex):
        """
        All descendants (any depth) whose line matches the regex
        :param regex: str or compiled pattern
        :return: list of ConfigNode
        """
        pattern = re.compile(regex) if isinstance(regex, str) else regex
        matches = []
        for child in self.children:
            if pattern.search(child.line):
                matches.append(child)
            matches.extend(child.find_all(pattern))
        return matches

    def child_lines(self):
        """
        Direct children as stripped strings
        :return: list of str
        """
        return [child.line for child in self.children]

    def section_text(self):
        """
        Reconstruct this node and its descendants as indented text
        :return: str
        """
        lines = [self.line]
        for child in self.children:
            lines.extend(
                " " * (node_depth - self.depth) + node_line
                for node_line, node_depth in child._walk()
            )
        return "\n".join(lines)

    def _walk(self):
        yield self.line, self.depth
        for child in self.children:
            yield from child._walk()

    def to_dict(self):
        """
        Recursively turn the node into a dictionary
        :return: dict
        """
        if not self.children:
            return {"line": self.line}
        return {"line": self.line, "children": [c.to_dict() for c in self.children]}


class ConfigTree:
    """
    Parses a running config into a hierarchy in a single pass.

    Usage:
        tree = ConfigTree(content)
        for node in tree.find_objects(r"^interface"):
            print(node.line, node.child_lines())
    """

    def __init__(self, content):
        self.content = content
        self.root = ConfigNode(line="", depth=-1)
        self._parse()

    def _parse(self):
        lines = self.content.splitlines()
        # stack of (indent, node); root sits at indent -1
        stack = [(-1, self.root)]

        index = 0
        total = len(lines)
        while index < total:
            raw = lines[index]
            index += 1

            stripped = raw.strip()
            if not stripped:
                continue
            # comment / separator lines carry no configuration
            if stripped.startswith("!"):
                continue
            if stripped == "end":
                continue

            indent = len(raw) - len(raw.lstrip())

            while stack and indent <= stack[-1][0]:
                stack.pop()

            node = ConfigNode(line=stripped, depth=indent)
            stack[-1][1].children.append(node)
            stack.append((indent, node))

            # banners span multiple non-indented lines until the closing
            # delimiter; swallow them into the banner node as children
            banner_regex = BANNER_REGEX.match(stripped)
            if banner_regex:
                delimiter = banner_regex.group(1)[0] if banner_regex.group(1) else "^C"
                if delimiter == "^":
                    delimiter = banner_regex.group(1)[:2]
                # banner opened and closed on the same line: nothing to swallow
                banner_remainder = stripped.split(delimiter, 1)[1] if delimiter in stripped else ""
                if delimiter in banner_remainder:
                    stack.pop()
                    continue
                while index < total:
                    banner_line = lines[index].rstrip("\n")
                    index += 1
                    if banner_line.strip() == delimiter or banner_line.strip().endswith(delimiter):
                        node.children.append(ConfigNode(line=banner_line.strip(), depth=indent + 1))
                        break
                    node.children.append(ConfigNode(line=banner_line, depth=indent + 1))
                stack.pop()

    def find_objects(self, regex):
        """
        Top-level sections whose first line matches the regex
        :param regex: str or compiled pattern
        :return: list of ConfigNode
        """
        pattern = re.compile(regex) if isinstance(regex, str) else regex
        return [node for node in self.root.children if pattern.search(node.line)]

    def find_all(self, regex):
        """
        Nodes at any depth whose line matches the regex
        :param regex: str or compiled pattern
        :return: list of ConfigNode
        """
        return self.root.find_all(regex)

    def top_level_lines(self):
        """
        All top-level lines (section headers and standalone commands)
        :return: list of str
        """
        return [node.line for node in self.root.children]

    def to_dict(self):
        """
        The whole config as a nested dictionary
        :return: list of dict
        """
        return [node.to_dict() for node in self.root.children]
