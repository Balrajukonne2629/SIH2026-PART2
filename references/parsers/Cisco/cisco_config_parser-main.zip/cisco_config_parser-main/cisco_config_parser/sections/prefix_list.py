# Description: Prefix-list parser for IOS/NXOS ("ip prefix-list ...") and
# IOS-XR prefix-sets.

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import PrefixList, PrefixListEntry, PrefixSet

PREFIX_LIST_ENTRY_REGEX = re.compile(
    r"^ip(?:v6)? prefix-list\s+(\S+)\s+seq\s+(\d+)\s+(permit|deny)\s+(\S+)"
    r"(?:\s+ge\s+(\d+))?(?:\s+le\s+(\d+))?"
)
PREFIX_LIST_DESCRIPTION_REGEX = re.compile(r"^ip(?:v6)? prefix-list\s+(\S+)\s+description\s+(.*)")
PREFIX_SET_REGEX = re.compile(r"^prefix-set\s+(\S+)")


@dataclass
class PrefixListParser:
    content: str = None

    def _fetch_prefix_lists(self, return_json=False):
        """
        Fetch all prefix-lists from the config file, grouped by name
        :return: list of PrefixList objects
        """
        tree = ConfigTree(self.content)
        prefix_lists = {}

        def get_list(name):
            if name not in prefix_lists:
                prefix_lists[name] = PrefixList(name=name)
            return prefix_lists[name]

        for node in tree.find_objects(r"^ip(v6)? prefix-list"):
            entry_regex = PREFIX_LIST_ENTRY_REGEX.match(node.line)
            if entry_regex:
                name, seq, action, prefix, ge, le = entry_regex.groups()
                get_list(name).entries.append(
                    PrefixListEntry(
                        sequence=seq, action=action, prefix=prefix,
                        ge=ge, le=le, raw=node.line,
                    )
                )
                continue

            description_regex = PREFIX_LIST_DESCRIPTION_REGEX.match(node.line)
            if description_regex:
                get_list(description_regex.group(1)).description = description_regex.group(2).strip()

        result = list(prefix_lists.values())
        if return_json:
            return [pl.to_dict() for pl in result]
        return result

    def _fetch_prefix_sets(self, return_json=False):
        """
        Fetch IOS-XR prefix-sets from the config file
        :return: list of PrefixSet objects
        """
        tree = ConfigTree(self.content)
        prefix_sets = []

        for section in tree.find_objects(PREFIX_SET_REGEX):
            name = PREFIX_SET_REGEX.match(section.line).group(1)
            prefixes = [
                child.line.rstrip(",")
                for child in section.children
                if child.line != "end-set"
            ]
            prefix_sets.append(PrefixSet(name=name, prefixes=prefixes))

        if return_json:
            return [ps.to_dict() for ps in prefix_sets]
        return prefix_sets
