# Description: LISP parser for SD-Access fabric nodes (IOS-XE
# "router lisp"): domain-id, locator-sets, services (ipv4/ethernet with
# map-resolvers / map-servers) and instance-ids with their dynamic-eids
# and database-mappings.
#
# Map-server authentication keys are detected but never stored.

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DictMixin, mask_secrets

ROUTER_LISP_REGEX = re.compile(r"^router lisp$")
DOMAIN_ID_REGEX = re.compile(r"^domain-id\s+(\S+)")
LOCATOR_SET_REGEX = re.compile(r"^locator-set\s+(\S+)")
LOCATOR_INTERFACE_REGEX = re.compile(
    r"^IPv[46]-interface\s+(\S+)(?:\s+priority\s+(\d+))?(?:\s+weight\s+(\d+))?"
)
SERVICE_REGEX = re.compile(r"^service\s+(\S+)")
ENCAPSULATION_REGEX = re.compile(r"^encapsulation\s+(\S+)")
ITR_MAP_RESOLVER_REGEX = re.compile(r"^itr map-resolver\s+(\S+)")
ETR_MAP_SERVER_REGEX = re.compile(r"^etr map-server\s+(\S+)\s+(key|proxy-reply)")
PROXY_ITR_REGEX = re.compile(r"^proxy-itr\s+(\S+)")
EID_TABLE_REGEX = re.compile(r"^eid-table\s+(\S+.*)")
INSTANCE_ID_REGEX = re.compile(r"^instance-id\s+(\d+)")
DYNAMIC_EID_REGEX = re.compile(r"^dynamic-eid\s+(\S+)")
DATABASE_MAPPING_REGEX = re.compile(r"^database-mapping\s+(\S+)(?:\s+locator-set\s+(\S+))?")
EXIT_LINE_REGEX = re.compile(r"^exit-")


@dataclass
class LISPService(DictMixin):
    name: str = None                # ipv4 / ipv6 / ethernet
    encapsulation: str = None
    itr: bool = False
    etr: bool = False
    sgt: bool = False
    proxy_itr: str = None
    itr_map_resolvers: list = field(default_factory=list)
    etr_map_servers: list = field(default_factory=list)   # {server, has_key, proxy_reply}
    eid_table: str = None
    children: list = field(default_factory=list)


@dataclass
class LISPDynamicEID(DictMixin):
    name: str = None
    database_mappings: list = field(default_factory=list)  # {prefix, locator_set}


@dataclass
class LISPInstance(DictMixin):
    instance_id: str = None
    dynamic_eids: list = field(default_factory=list)
    services: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class LISPRouter(DictMixin):
    domain_id: str = None
    locator_sets: list = field(default_factory=list)   # {name, interfaces}
    services: list = field(default_factory=list)
    instances: list = field(default_factory=list)
    children: list = field(default_factory=list)


def _clean_children(node):
    # drop exit-* markers and mask key hashes in the raw lines
    return [
        mask_secrets(line)
        for line in node.child_lines()
        if not EXIT_LINE_REGEX.match(line)
    ]


def _parse_service(service_node):
    """
    Parse a "service ipv4|ipv6|ethernet" section (top level or inside an
    instance-id)
    :return: LISPService
    """
    service = LISPService(
        name=SERVICE_REGEX.match(service_node.line).group(1),
        children=_clean_children(service_node),
    )
    map_servers = {}
    for child in service_node.children:
        line = child.line

        if line == "itr":
            service.itr = True
            continue
        if line == "etr":
            service.etr = True
            continue
        if line == "sgt":
            service.sgt = True
            continue

        encapsulation_regex = ENCAPSULATION_REGEX.match(line)
        if encapsulation_regex:
            service.encapsulation = encapsulation_regex.group(1)
            continue

        resolver_regex = ITR_MAP_RESOLVER_REGEX.match(line)
        if resolver_regex:
            service.itr_map_resolvers.append(resolver_regex.group(1))
            continue

        map_server_regex = ETR_MAP_SERVER_REGEX.match(line)
        if map_server_regex:
            server, attribute = map_server_regex.groups()
            entry = map_servers.setdefault(
                server, {"server": server, "has_key": False, "proxy_reply": False}
            )
            if attribute == "key":
                entry["has_key"] = True   # the key hash is deliberately not stored
            else:
                entry["proxy_reply"] = True
            continue

        proxy_itr_regex = PROXY_ITR_REGEX.match(line)
        if proxy_itr_regex:
            service.proxy_itr = proxy_itr_regex.group(1)
            continue

        eid_table_regex = EID_TABLE_REGEX.match(line)
        if eid_table_regex:
            service.eid_table = eid_table_regex.group(1).strip()

    service.etr_map_servers = list(map_servers.values())
    return service


@dataclass
class LISPParser:
    content: str = None

    def _fetch_lisp_config(self, return_json=False):
        """
        Fetch the LISP configuration from the config file
        :return: LISPRouter object or None when "router lisp" is absent
        """
        tree = ConfigTree(self.content)
        sections = tree.find_objects(ROUTER_LISP_REGEX)
        if not sections:
            return None

        lisp_section = sections[0]
        lisp = LISPRouter(children=_clean_children(lisp_section))

        for child in lisp_section.children:
            line = child.line

            domain_regex = DOMAIN_ID_REGEX.match(line)
            if domain_regex:
                lisp.domain_id = domain_regex.group(1)
                continue

            locator_set_regex = LOCATOR_SET_REGEX.match(line)
            if locator_set_regex:
                interfaces = []
                for locator_child in child.children:
                    intf_regex = LOCATOR_INTERFACE_REGEX.match(locator_child.line)
                    if intf_regex:
                        interfaces.append({
                            "interface": intf_regex.group(1),
                            "priority": intf_regex.group(2),
                            "weight": intf_regex.group(3),
                        })
                lisp.locator_sets.append(
                    {"name": locator_set_regex.group(1), "interfaces": interfaces}
                )
                continue

            if SERVICE_REGEX.match(line):
                lisp.services.append(_parse_service(child))
                continue

            instance_regex = INSTANCE_ID_REGEX.match(line)
            if instance_regex:
                instance = LISPInstance(
                    instance_id=instance_regex.group(1),
                    children=_clean_children(child),
                )
                for instance_child in child.children:
                    dynamic_eid_regex = DYNAMIC_EID_REGEX.match(instance_child.line)
                    if dynamic_eid_regex:
                        dynamic_eid = LISPDynamicEID(name=dynamic_eid_regex.group(1))
                        for eid_child in instance_child.children:
                            mapping_regex = DATABASE_MAPPING_REGEX.match(eid_child.line)
                            if mapping_regex:
                                dynamic_eid.database_mappings.append({
                                    "prefix": mapping_regex.group(1),
                                    "locator_set": mapping_regex.group(2),
                                })
                        instance.dynamic_eids.append(dynamic_eid)
                        continue

                    if SERVICE_REGEX.match(instance_child.line):
                        instance.services.append(_parse_service(instance_child))

                lisp.instances.append(instance)

        if return_json:
            return lisp.to_dict()
        return lisp
