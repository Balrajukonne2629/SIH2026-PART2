# Description: Dataclass objects returned by the section parsers (ACL,
# prefix-list, route-map, VRF, device identity).

import re
from dataclasses import dataclass, field, asdict

# "key 7 <hash>" / "server-key 7 <hash>" material must never appear in output
SECRET_KEY_REGEX = re.compile(r"(\b(?:server-)?key\s+[0-7]\s+)\S+")


def mask_secrets(line):
    """
    Replace key/password hashes in a raw config line with <hidden>
    """
    return SECRET_KEY_REGEX.sub(r"\1<hidden>", line)


class DictMixin:
    def to_dict(self):
        # Recursively turn the instance into a dictionary
        return asdict(self)


# ---------------------------------------------------------------- access-list
@dataclass
class ACLEntry(DictMixin):
    sequence: str = None
    action: str = None
    protocol: str = None
    source: str = None
    source_port: str = None
    destination: str = None
    destination_port: str = None
    options: str = None
    raw: str = None


@dataclass
class AccessList(DictMixin):
    name: str = None
    type: str = None            # standard / extended / unknown
    style: str = None           # named / numbered
    remarks: list = field(default_factory=list)
    entries: list = field(default_factory=list)


# --------------------------------------------------------------- prefix-list
@dataclass
class PrefixListEntry(DictMixin):
    sequence: str = None
    action: str = None
    prefix: str = None
    le: str = None
    ge: str = None
    raw: str = None


@dataclass
class PrefixList(DictMixin):
    name: str = None
    description: str = None
    entries: list = field(default_factory=list)


@dataclass
class PrefixSet(DictMixin):
    # IOS-XR prefix-set
    name: str = None
    prefixes: list = field(default_factory=list)


# ------------------------------------------------------------ community-list
@dataclass
class CommunityListEntry(DictMixin):
    sequence: str = None
    action: str = None
    communities: list = field(default_factory=list)   # values, or one regex for expanded
    raw: str = None


@dataclass
class CommunityList(DictMixin):
    name: str = None
    type: str = None            # standard / expanded
    style: str = None           # named / numbered
    entries: list = field(default_factory=list)


@dataclass
class CommunitySet(DictMixin):
    # IOS-XR community-set / extcommunity-set
    name: str = None
    type: str = None            # None for community-set, rt/soo for extcommunity-set
    communities: list = field(default_factory=list)


# ----------------------------------------------------------------- route-map
@dataclass
class RouteMapClause(DictMixin):
    action: str = None          # permit / deny
    sequence: str = None
    description: str = None
    match: list = field(default_factory=list)
    set: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class RouteMap(DictMixin):
    name: str = None
    clauses: list = field(default_factory=list)


@dataclass
class RoutePolicy(DictMixin):
    # IOS-XR route-policy; the body is an RPL program, kept as raw lines
    name: str = None
    lines: list = field(default_factory=list)


# ----------------------------------------------------------------------- vrf
@dataclass
class VRFAddressFamily(DictMixin):
    name: str = None
    route_target_import: list = field(default_factory=list)
    route_target_export: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class VRF(DictMixin):
    name: str = None
    rd: str = None
    description: str = None
    address_families: list = field(default_factory=list)
    children: list = field(default_factory=list)


# ----------------------------------------------------------- device identity
@dataclass
class User(DictMixin):
    name: str = None
    privilege: str = None
    secret_type: str = None     # secret / password
    raw: str = None


@dataclass
class LineConfig(DictMixin):
    name: str = None            # e.g. "vty 0 4", "con 0"
    access_class: str = None
    transport_input: str = None
    exec_timeout: str = None
    children: list = field(default_factory=list)


@dataclass
class SNMPConfig(DictMixin):
    communities: list = field(default_factory=list)   # {community, mode, acl}
    location: str = None
    contact: str = None
    hosts: list = field(default_factory=list)
    users: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class DeviceIdentity(DictMixin):
    hostname: str = None
    version: str = None
    domain_name: str = None
    name_servers: list = field(default_factory=list)
    ntp_servers: list = field(default_factory=list)
    logging_hosts: list = field(default_factory=list)
    logging_trap: str = None
    users: list = field(default_factory=list)
    aaa: list = field(default_factory=list)
    lines: list = field(default_factory=list)
    snmp: SNMPConfig = field(default_factory=SNMPConfig)
    features: list = field(default_factory=list)      # NXOS "feature" flags
