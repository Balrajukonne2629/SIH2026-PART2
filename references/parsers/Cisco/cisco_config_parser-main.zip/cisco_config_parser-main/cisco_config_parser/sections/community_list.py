# Description: BGP community-list parser. Handles IOS named/numbered
# standard and expanded lists, NXOS sequenced lists, and IOS-XR
# community-sets.

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import CommunityList, CommunityListEntry, CommunitySet

COMMUNITY_LIST_REGEX = re.compile(
    r"^ip community-list\s+(?:(standard|expanded)\s+)?(\S+)"
    r"(?:\s+seq\s+(\d+))?\s+(permit|deny)\s+(.*)"
)
COMMUNITY_SET_REGEX = re.compile(r"^community-set\s+(\S+)")
EXTCOMMUNITY_SET_REGEX = re.compile(r"^extcommunity-set\s+(rt|soo)\s+(\S+)")


def _numbered_community_list_type(number):
    # IOS convention: 1-99 standard, 100-500 expanded
    return "standard" if int(number) < 100 else "expanded"


@dataclass
class CommunityListParser:
    content: str = None

    def _fetch_community_lists(self, return_json=False):
        """
        Fetch all community-lists from the config file, grouped by name
        :return: list of CommunityList objects
        """
        tree = ConfigTree(self.content)
        community_lists = {}

        for node in tree.find_objects(COMMUNITY_LIST_REGEX):
            cl_regex = COMMUNITY_LIST_REGEX.match(node.line)
            cl_type, name, sequence, action, values = cl_regex.groups()

            if cl_type is None:
                cl_type = (
                    _numbered_community_list_type(name) if name.isdigit() else "standard"
                )

            community_list = community_lists.get(name)
            if community_list is None:
                community_list = CommunityList(
                    name=name,
                    type=cl_type,
                    style="numbered" if name.isdigit() else "named",
                )
                community_lists[name] = community_list

            values = values.strip()
            if cl_type == "expanded":
                # expanded lists take one regex, possibly quoted
                communities = [values.strip('"')]
            else:
                communities = values.split()

            community_list.entries.append(
                CommunityListEntry(
                    sequence=sequence,
                    action=action,
                    communities=communities,
                    raw=node.line,
                )
            )

        result = list(community_lists.values())
        if return_json:
            return [cl.to_dict() for cl in result]
        return result

    def _fetch_community_sets(self, return_json=False):
        """
        Fetch IOS-XR community-sets from the config file
        :return: list of CommunitySet objects
        """
        tree = ConfigTree(self.content)
        community_sets = []

        for section in tree.find_objects(COMMUNITY_SET_REGEX):
            name = COMMUNITY_SET_REGEX.match(section.line).group(1)
            communities = [
                child.line.rstrip(",")
                for child in section.children
                if child.line != "end-set"
            ]
            community_sets.append(CommunitySet(name=name, communities=communities))

        if return_json:
            return [cs.to_dict() for cs in community_sets]
        return community_sets

    def _fetch_extcommunity_sets(self, return_json=False):
        """
        Fetch IOS-XR extcommunity-sets (rt / soo) from the config file
        :return: list of CommunitySet objects (type carries rt/soo)
        """
        tree = ConfigTree(self.content)
        extcommunity_sets = []

        for section in tree.find_objects(EXTCOMMUNITY_SET_REGEX):
            set_type, name = EXTCOMMUNITY_SET_REGEX.match(section.line).groups()
            communities = [
                child.line.rstrip(",")
                for child in section.children
                if child.line != "end-set"
            ]
            extcommunity_sets.append(
                CommunitySet(name=name, type=set_type, communities=communities)
            )

        if return_json:
            return [es.to_dict() for es in extcommunity_sets]
        return extcommunity_sets
