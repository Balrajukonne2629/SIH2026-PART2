# Description: Cross-reference validator. Collects the policy objects a
# config defines (route-maps, prefix-lists/sets, community-lists/sets, ACLs,
# route-policies, VRFs) and every place those object types are referenced,
# then reports references to undefined objects (broken config) and defined
# objects that are never referenced (dead config).
#
# "Unused" is a best-effort audit hint: an object may be referenced by a
# feature this library does not scan yet (NAT, class-maps, ...).

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .acl import ACLParser
from .prefix_list import PrefixListParser
from .route_map import RouteMapParser
from .community_list import CommunityListParser
from .vrf import VRFParser

# vrfs that exist implicitly on the platform without a definition
IMPLICIT_VRFS = {"default", "management", "Mgmt-intf", "Mgmt-vrf", "mgmtVrf"}

ROUTE_MAP_DEF_REGEX = re.compile(r"^route-map\s")
ROUTE_MAP_REF_REGEX = re.compile(r"\broute-map\s+(\S+)")
ROUTE_POLICY_DEF_REGEX = re.compile(r"^route-policy\s")
ROUTE_POLICY_REF_REGEX = re.compile(r"\broute-policy\s+(\S+)")
PREFIX_LIST_DEF_REGEX = re.compile(r"^ip(?:v6)? prefix-list\s")
PREFIX_LIST_REF_REGEX = re.compile(r"\bprefix-list\s+(.+)$")
PREFIX_SET_REF_REGEX = re.compile(r"\b(?:destination|source)\s+in\s+(\S+)")
COMMUNITY_LIST_REF_REGEX = re.compile(r"^match (?:ext)?community\s+(.+)$")
COMMUNITY_SET_REF_REGEX = re.compile(r"(?<!ext)community\s+matches-(?:any|every)\s+(\S+)")
EXTCOMMUNITY_SET_REF_REGEX = re.compile(
    r"extcommunity\s+(?:rt|soo)\s+matches-(?:any|every)\s+(\S+)"
    r"|set\s+extcommunity\s+(?:rt|soo)\s+(\S+)"
)
ACL_GROUP_REF_REGEX = re.compile(r"^(?:ip |ipv4 |ipv6 )?access-group\s+(\S+)")
ACL_CLASS_REF_REGEX = re.compile(r"^(?:ip )?access-class\s+(\S+)\s+(?:in|out)")
ACL_MATCH_REF_REGEX = re.compile(r"^match ip address\s+(?!prefix-list)(.+)$")
VRF_REF_REGEX = re.compile(r"^(?:ip )?vrf\s+(?:forwarding|member)\s+(\S+)")
VRF_STATIC_REF_REGEX = re.compile(r"^ip route vrf\s+(\S+)")
VRF_AF_REF_REGEX = re.compile(r"^address-family\s+\S+(?:\s+\S+)?\s+vrf\s+(\S+)")
ROUTER_SECTION_REGEX = re.compile(r"^router\s")
ROUTER_VRF_REF_REGEX = re.compile(r"^vrf\s+(\S+)$")

COMMUNITY_KEYWORDS = {"exact-match"}


@dataclass
class CrossReferenceValidator:
    content: str = None

    def _validate(self):
        """
        Build the cross-reference report
        :return: dict with "undefined_references" and "unused_definitions"
        """
        tree = ConfigTree(self.content)
        definitions = self._collect_definitions()
        references = self._collect_references(tree)

        undefined = {}
        unused = {}
        for object_type, defined_names in definitions.items():
            referenced = references.get(object_type, {})

            missing = [
                {"name": name, "lines": sorted(lines)}
                for name, lines in sorted(referenced.items())
                if name not in defined_names
            ]
            if missing:
                undefined[object_type] = missing

            dead = sorted(defined_names - set(referenced))
            if dead:
                unused[object_type] = dead

        return {"undefined_references": undefined, "unused_definitions": unused}

    def _collect_definitions(self):
        """
        Names of every policy object the config defines, per type
        :return: dict of type -> set of names
        """
        acl_parser = ACLParser(self.content)
        prefix_parser = PrefixListParser(self.content)
        route_map_parser = RouteMapParser(self.content)
        community_parser = CommunityListParser(self.content)
        vrf_parser = VRFParser(self.content)

        return {
            "route_map": {rm.name for rm in route_map_parser._fetch_route_maps()},
            "route_policy": {rp.name for rp in route_map_parser._fetch_route_policies()},
            "prefix_list": {pl.name for pl in prefix_parser._fetch_prefix_lists()},
            "prefix_set": {ps.name for ps in prefix_parser._fetch_prefix_sets()},
            "community_list": {cl.name for cl in community_parser._fetch_community_lists()},
            "community_set": {cs.name for cs in community_parser._fetch_community_sets()},
            "extcommunity_set": {es.name for es in community_parser._fetch_extcommunity_sets()},
            "access_list": {acl.name for acl in acl_parser._fetch_access_lists()},
            "vrf": {vrf.name for vrf in vrf_parser._fetch_vrfs()},
        }

    def _collect_references(self, tree):
        """
        Every reference site in the config, per type:
        type -> {name: set of referencing lines}
        """
        references = {
            "route_map": {}, "route_policy": {},
            "prefix_list": {}, "prefix_set": {},
            "community_list": {}, "community_set": {}, "extcommunity_set": {},
            "access_list": {}, "vrf": {},
        }

        def add(object_type, name, line):
            references[object_type].setdefault(name, set()).add(line)

        def scan(node, inside_router_section, top_level):
            line = node.line

            # definition lines only exist at the top level; a nested
            # "route-map X in" (NXOS/XR) is a reference, not a definition
            if not (top_level and ROUTE_MAP_DEF_REGEX.match(line)):
                route_map_ref = ROUTE_MAP_REF_REGEX.search(line)
                if route_map_ref:
                    add("route_map", route_map_ref.group(1), line)

            if not (top_level and ROUTE_POLICY_DEF_REGEX.match(line)):
                route_policy_ref = ROUTE_POLICY_REF_REGEX.search(line)
                if route_policy_ref:
                    add("route_policy", route_policy_ref.group(1), line)

            if not (top_level and PREFIX_LIST_DEF_REGEX.match(line)):
                prefix_list_ref = PREFIX_LIST_REF_REGEX.search(line)
                if prefix_list_ref:
                    for name in prefix_list_ref.group(1).split():
                        add("prefix_list", name, line)

            prefix_set_ref = PREFIX_SET_REF_REGEX.search(line)
            if prefix_set_ref:
                add("prefix_set", prefix_set_ref.group(1), line)

            community_list_ref = COMMUNITY_LIST_REF_REGEX.match(line)
            if community_list_ref:
                for name in community_list_ref.group(1).split():
                    if name not in COMMUNITY_KEYWORDS:
                        add("community_list", name, line)

            community_set_ref = COMMUNITY_SET_REF_REGEX.search(line)
            if community_set_ref:
                add("community_set", community_set_ref.group(1), line)

            extcommunity_set_ref = EXTCOMMUNITY_SET_REF_REGEX.search(line)
            if extcommunity_set_ref:
                name = extcommunity_set_ref.group(1) or extcommunity_set_ref.group(2)
                add("extcommunity_set", name, line)

            for acl_regex in (ACL_GROUP_REF_REGEX, ACL_CLASS_REF_REGEX):
                acl_ref = acl_regex.match(line)
                if acl_ref:
                    add("access_list", acl_ref.group(1), line)

            acl_match_ref = ACL_MATCH_REF_REGEX.match(line)
            if acl_match_ref:
                for name in acl_match_ref.group(1).split():
                    add("access_list", name, line)

            for vrf_regex in (VRF_REF_REGEX, VRF_STATIC_REF_REGEX, VRF_AF_REF_REGEX):
                vrf_ref = vrf_regex.match(line)
                if vrf_ref:
                    add("vrf", vrf_ref.group(1), line)

            # "vrf X" subsections inside router bgp/ospf/... reference a vrf
            if inside_router_section:
                router_vrf_ref = ROUTER_VRF_REF_REGEX.match(line)
                if router_vrf_ref:
                    add("vrf", router_vrf_ref.group(1), line)

            for child in node.children:
                scan(
                    child,
                    inside_router_section or bool(ROUTER_SECTION_REGEX.match(line)),
                    top_level=False,
                )

        for top_node in tree.root.children:
            scan(top_node, inside_router_section=False, top_level=True)

        # snmp community ACLs come from the identity parser (position-based)
        from .identity import DeviceIdentityParser
        identity = DeviceIdentityParser(self.content)._fetch_device_identity()
        for community in identity.snmp.communities:
            if community.get("acl"):
                add("access_list", community["acl"], f"snmp-server community ... {community['acl']}")

        for object_type, names in references.items():
            for implicit in list(names):
                if object_type == "vrf" and implicit in IMPLICIT_VRFS:
                    del names[implicit]

        return references
