# Description: Route-map parser for IOS/NXOS and route-policy capture for
# IOS-XR.

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import RouteMap, RouteMapClause, RoutePolicy

ROUTE_MAP_REGEX = re.compile(r"^route-map\s+(\S+)(?:\s+(permit|deny))?(?:\s+(\d+))?")
ROUTE_POLICY_REGEX = re.compile(r"^route-policy\s+(\S+)")


@dataclass
class RouteMapParser:
    content: str = None

    def _fetch_route_maps(self, return_json=False):
        """
        Fetch all route-maps from the config file, grouped by name.
        Each "route-map NAME permit|deny SEQ" section becomes one clause.
        :return: list of RouteMap objects
        """
        tree = ConfigTree(self.content)
        route_maps = {}

        for section in tree.find_objects(ROUTE_MAP_REGEX):
            rm_regex = ROUTE_MAP_REGEX.match(section.line)
            name, action, sequence = rm_regex.groups()

            if name not in route_maps:
                route_maps[name] = RouteMap(name=name)

            clause = RouteMapClause(
                action=action or "permit",
                sequence=sequence,
                children=section.child_lines(),
            )
            for line in clause.children:
                if line.startswith("match "):
                    clause.match.append(line.replace("match ", "", 1).strip())
                elif line.startswith("set "):
                    clause.set.append(line.replace("set ", "", 1).strip())
                elif line.startswith("description "):
                    clause.description = line.replace("description ", "", 1).strip()

            route_maps[name].clauses.append(clause)

        result = list(route_maps.values())
        if return_json:
            return [rm.to_dict() for rm in result]
        return result

    def _fetch_route_policies(self, return_json=False):
        """
        Fetch IOS-XR route-policies. RPL bodies are programs, not key/value
        config, so they are captured as raw lines.
        :return: list of RoutePolicy objects
        """
        tree = ConfigTree(self.content)
        route_policies = []

        for section in tree.find_objects(ROUTE_POLICY_REGEX):
            name = ROUTE_POLICY_REGEX.match(section.line).group(1)
            lines = [line for line, _ in section._walk()][1:]
            lines = [line for line in lines if line != "end-policy"]
            route_policies.append(RoutePolicy(name=name, lines=lines))

        if return_json:
            return [rp.to_dict() for rp in route_policies]
        return route_policies
