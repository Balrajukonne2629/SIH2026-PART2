# Description: NetFlow / Flexible NetFlow parser. Handles the IOS-XE
# sections (flow record / flow exporter / flow monitor) and the IOS-XR
# map forms (flow exporter-map / flow monitor-map / sampler-map), plus
# the interface attachments on both platforms.

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DictMixin

FLOW_RECORD_REGEX = re.compile(r"^flow record\s+(\S+)")
FLOW_EXPORTER_REGEX = re.compile(r"^flow exporter(?:-map)?\s+(\S+)")
FLOW_MONITOR_REGEX = re.compile(r"^flow monitor(?:-map)?\s+(\S+)")
SAMPLER_MAP_REGEX = re.compile(r"^sampler-map\s+(\S+)")

DESCRIPTION_REGEX = re.compile(r"^description\s+(.*)")
MATCH_REGEX = re.compile(r"^match\s+(.*)")
COLLECT_REGEX = re.compile(r"^collect\s+(.*)")
DESTINATION_REGEX = re.compile(r"^destination\s+(\S+)(?:\s+vrf\s+(\S+))?")
SOURCE_REGEX = re.compile(r"^source\s+(\S+)")
TRANSPORT_REGEX = re.compile(r"^transport udp\s+(\d+)")
VERSION_REGEX = re.compile(r"^version\s+(\S+)")
RECORD_REGEX = re.compile(r"^record\s+(\S+)")
MONITOR_EXPORTER_REGEX = re.compile(r"^exporter\s+(\S+)")
CACHE_REGEX = re.compile(r"^cache\s+(.*)")
RANDOM_SAMPLER_REGEX = re.compile(r"^random\s+(\d+)\s+out-of\s+(\d+)")

INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")
# IOS-XE: "ip flow monitor NAME input" / "ipv6 flow monitor NAME output"
XE_ATTACH_REGEX = re.compile(r"^ip(v6)? flow monitor\s+(\S+)\s+(input|output)")
# IOS-XR: "flow ipv4 monitor NAME [sampler S] ingress|egress"
XR_ATTACH_REGEX = re.compile(
    r"^flow (ipv[46]|mpls) monitor\s+(\S+)(?:\s+sampler\s+(\S+))?\s+(ingress|egress)"
)


@dataclass
class FlowRecord(DictMixin):
    name: str = None
    description: str = None
    match: list = field(default_factory=list)
    collect: list = field(default_factory=list)


@dataclass
class FlowExporter(DictMixin):
    name: str = None
    description: str = None
    destination: str = None
    destination_vrf: str = None
    source: str = None
    transport_udp_port: str = None
    version: str = None
    children: list = field(default_factory=list)


@dataclass
class FlowMonitor(DictMixin):
    name: str = None
    description: str = None
    record: str = None
    exporters: list = field(default_factory=list)
    cache: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class FlowSampler(DictMixin):
    name: str = None
    mode: str = None            # e.g. "random 1 out-of 10000"
    children: list = field(default_factory=list)


@dataclass
class NetflowConfig(DictMixin):
    records: list = field(default_factory=list)
    exporters: list = field(default_factory=list)
    monitors: list = field(default_factory=list)
    samplers: list = field(default_factory=list)
    interface_attachments: list = field(default_factory=list)
    # {interface, monitor, direction, family, sampler}


@dataclass
class NetflowParser:
    content: str = None

    def _fetch_netflow(self, return_json=False):
        """
        Fetch the NetFlow configuration from the config file
        :return: NetflowConfig object
        """
        tree = ConfigTree(self.content)
        netflow = NetflowConfig()

        for node in tree.root.children:
            line = node.line

            record_regex = FLOW_RECORD_REGEX.match(line)
            if record_regex:
                record = FlowRecord(name=record_regex.group(1))
                for child in node.children:
                    description_regex = DESCRIPTION_REGEX.match(child.line)
                    if description_regex:
                        record.description = description_regex.group(1).strip()
                    match_regex = MATCH_REGEX.match(child.line)
                    if match_regex:
                        record.match.append(match_regex.group(1).strip())
                    collect_regex = COLLECT_REGEX.match(child.line)
                    if collect_regex:
                        record.collect.append(collect_regex.group(1).strip())
                netflow.records.append(record)
                continue

            exporter_regex = FLOW_EXPORTER_REGEX.match(line)
            if exporter_regex:
                netflow.exporters.append(self._parse_exporter(node, exporter_regex.group(1)))
                continue

            monitor_regex = FLOW_MONITOR_REGEX.match(line)
            if monitor_regex:
                monitor = FlowMonitor(
                    name=monitor_regex.group(1), children=node.child_lines(),
                )
                for child in node.children:
                    description_regex = DESCRIPTION_REGEX.match(child.line)
                    if description_regex:
                        monitor.description = description_regex.group(1).strip()
                    record_ref_regex = RECORD_REGEX.match(child.line)
                    if record_ref_regex:
                        monitor.record = record_ref_regex.group(1)
                    exporter_ref_regex = MONITOR_EXPORTER_REGEX.match(child.line)
                    if exporter_ref_regex:
                        monitor.exporters.append(exporter_ref_regex.group(1))
                    cache_regex = CACHE_REGEX.match(child.line)
                    if cache_regex:
                        monitor.cache.append(cache_regex.group(1).strip())
                netflow.monitors.append(monitor)
                continue

            sampler_regex = SAMPLER_MAP_REGEX.match(line)
            if sampler_regex:
                sampler = FlowSampler(
                    name=sampler_regex.group(1), children=node.child_lines(),
                )
                for child in node.children:
                    if RANDOM_SAMPLER_REGEX.match(child.line):
                        sampler.mode = child.line
                netflow.samplers.append(sampler)
                continue

        # interface attachments (both platforms)
        for intf_section in tree.find_objects(INTERFACE_REGEX):
            intf_name = INTERFACE_REGEX.match(intf_section.line).group(1)
            for child in intf_section.children:
                xe_regex = XE_ATTACH_REGEX.match(child.line)
                if xe_regex:
                    netflow.interface_attachments.append({
                        "interface": intf_name,
                        "family": "ipv6" if xe_regex.group(1) else "ipv4",
                        "monitor": xe_regex.group(2),
                        "sampler": None,
                        "direction": xe_regex.group(3),
                    })
                    continue
                xr_regex = XR_ATTACH_REGEX.match(child.line)
                if xr_regex:
                    netflow.interface_attachments.append({
                        "interface": intf_name,
                        "family": xr_regex.group(1),
                        "monitor": xr_regex.group(2),
                        "sampler": xr_regex.group(3),
                        "direction": xr_regex.group(4),
                    })

        if return_json:
            return netflow.to_dict()
        return netflow

    @staticmethod
    def _parse_exporter(node, name):
        exporter = FlowExporter(name=name, children=node.child_lines())
        for child in node.children:
            description_regex = DESCRIPTION_REGEX.match(child.line)
            if description_regex:
                exporter.description = description_regex.group(1).strip()
                continue
            destination_regex = DESTINATION_REGEX.match(child.line)
            if destination_regex:
                exporter.destination, exporter.destination_vrf = destination_regex.groups()
                continue
            source_regex = SOURCE_REGEX.match(child.line)
            if source_regex:
                exporter.source = source_regex.group(1)
                continue
            transport_regex = TRANSPORT_REGEX.match(child.line)
            if transport_regex:
                exporter.transport_udp_port = transport_regex.group(1)
                continue
            version_regex = VERSION_REGEX.match(child.line)
            if version_regex:
                exporter.version = version_regex.group(1)
        return exporter
