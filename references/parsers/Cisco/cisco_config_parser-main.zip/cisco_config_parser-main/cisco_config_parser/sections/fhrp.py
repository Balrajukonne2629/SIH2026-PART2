# Description: First-hop redundancy (HSRP/VRRP) parser. IOS configures
# groups as flat interface lines ("standby 1 ip 10.1.1.1"); NXOS uses
# nested subsections ("hsrp 1" > "ip 10.1.1.1").

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DictMixin

INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")

# IOS flat style: standby [version N] / standby <grp> <attr> ...; vrrp <grp> <attr> ...
IOS_HSRP_VERSION_REGEX = re.compile(r"^standby version\s+(\d+)")
IOS_FHRP_LINE_REGEX = re.compile(r"^(standby|vrrp)\s+(\d+)\s+(.*)")

# NXOS nested style: hsrp <grp> / vrrp <grp> subsections
NXOS_FHRP_SECTION_REGEX = re.compile(r"^(hsrp|vrrp)\s+(\d+)")
NXOS_HSRP_VERSION_REGEX = re.compile(r"^hsrp version\s+(\d+)")

VIP_REGEX = re.compile(r"^(?:ip|address)\s+(\d+\.\d+\.\d+\.\d+)")
PRIORITY_REGEX = re.compile(r"^priority\s+(\d+)")
TRACK_REGEX = re.compile(r"^track\s+(.*)")


@dataclass
class FHRPGroup(DictMixin):
    interface: str = None
    protocol: str = None        # hsrp / vrrp
    group: str = None
    vip: str = None
    priority: str = None
    preempt: bool = False
    version: str = None
    track: list = field(default_factory=list)
    children: list = field(default_factory=list)


@dataclass
class FHRPParser:
    content: str = None

    def _fetch_fhrp_groups(self, return_json=False):
        """
        Fetch all HSRP/VRRP groups from the config file
        :return: list of FHRPGroup objects
        """
        tree = ConfigTree(self.content)
        groups = []

        for intf_section in tree.find_objects(INTERFACE_REGEX):
            intf_name = INTERFACE_REGEX.match(intf_section.line).group(1)
            intf_groups = {}
            version = None

            for child in intf_section.children:
                version_regex = (
                    IOS_HSRP_VERSION_REGEX.match(child.line)
                    or NXOS_HSRP_VERSION_REGEX.match(child.line)
                )
                if version_regex:
                    version = version_regex.group(1)
                    continue

                # IOS flat lines
                ios_regex = IOS_FHRP_LINE_REGEX.match(child.line)
                if ios_regex:
                    protocol_name = "hsrp" if ios_regex.group(1) == "standby" else "vrrp"
                    group = self._get_group(intf_groups, groups, intf_name, protocol_name, ios_regex.group(2))
                    group.children.append(child.line)
                    self._apply_attribute(group, ios_regex.group(3).strip())
                    continue

                # NXOS nested sections
                nxos_regex = NXOS_FHRP_SECTION_REGEX.match(child.line)
                if nxos_regex:
                    group = self._get_group(intf_groups, groups, intf_name, nxos_regex.group(1), nxos_regex.group(2))
                    group.children.extend(child.child_lines())
                    for group_child in child.children:
                        self._apply_attribute(group, group_child.line)

            for group in intf_groups.values():
                group.version = version

        if return_json:
            return [group.to_dict() for group in groups]
        return groups

    @staticmethod
    def _get_group(intf_groups, groups, interface, protocol, group_id):
        key = (protocol, group_id)
        if key not in intf_groups:
            group = FHRPGroup(interface=interface, protocol=protocol, group=group_id)
            intf_groups[key] = group
            groups.append(group)
        return intf_groups[key]

    @staticmethod
    def _apply_attribute(group, attribute_line):
        """
        Apply one group attribute ("ip 10.1.1.1", "priority 110", ...)
        """
        vip_regex = VIP_REGEX.match(attribute_line)
        if vip_regex:
            group.vip = vip_regex.group(1)
            return

        priority_regex = PRIORITY_REGEX.match(attribute_line)
        if priority_regex:
            group.priority = priority_regex.group(1)
            return

        if attribute_line == "preempt" or attribute_line.startswith("preempt "):
            group.preempt = True
            return

        track_regex = TRACK_REGEX.match(attribute_line)
        if track_regex:
            group.track.append(track_regex.group(1).strip())
