# Description: NXOS vPC parser. Parses the "vpc domain" section and
# correlates it with the peer-link and the vpc-attached port-channels
# configured on the interfaces.

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DictMixin

VPC_DOMAIN_REGEX = re.compile(r"^vpc domain\s+(\d+)")
ROLE_PRIORITY_REGEX = re.compile(r"^role priority\s+(\d+)")
SYSTEM_PRIORITY_REGEX = re.compile(r"^system-priority\s+(\d+)")
SYSTEM_MAC_REGEX = re.compile(r"^system-mac\s+(\S+)")
PEER_KEEPALIVE_REGEX = re.compile(
    r"^peer-keepalive destination\s+(\S+)(?:\s+source\s+(\S+))?(?:\s+vrf\s+(\S+))?"
)
DELAY_RESTORE_REGEX = re.compile(r"^delay restore\s+(\d+)")
AUTO_RECOVERY_REGEX = re.compile(r"^auto-recovery(?:\s+reload-delay\s+(\d+))?")

INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")
VPC_PEER_LINK_REGEX = re.compile(r"^vpc peer-link$")
VPC_ID_REGEX = re.compile(r"^vpc\s+(\d+)$")


@dataclass
class VPCDomain(DictMixin):
    domain_id: str = None
    role_priority: str = None
    system_priority: str = None
    system_mac: str = None
    peer_keepalive: dict = field(default_factory=dict)   # {destination, source, vrf}
    peer_switch: bool = False
    peer_gateway: bool = False
    auto_recovery: bool = False
    auto_recovery_reload_delay: str = None
    delay_restore: str = None
    layer3_peer_router: bool = False
    ip_arp_synchronize: bool = False
    peer_link: str = None                                # e.g. port-channel100
    vpc_port_channels: list = field(default_factory=list)  # {interface, vpc_id}
    children: list = field(default_factory=list)


@dataclass
class VPCParser:
    content: str = None

    def _fetch_vpc_config(self, return_json=False):
        """
        Fetch the vPC configuration from the config file
        :return: VPCDomain object or None when vpc is not configured
        """
        tree = ConfigTree(self.content)
        sections = tree.find_objects(VPC_DOMAIN_REGEX)
        if not sections:
            return None

        section = sections[0]
        vpc = VPCDomain(
            domain_id=VPC_DOMAIN_REGEX.match(section.line).group(1),
            children=section.child_lines(),
        )

        for child in section.children:
            line = child.line

            for attr, regex in (
                ("role_priority", ROLE_PRIORITY_REGEX),
                ("system_priority", SYSTEM_PRIORITY_REGEX),
                ("system_mac", SYSTEM_MAC_REGEX),
                ("delay_restore", DELAY_RESTORE_REGEX),
            ):
                found = regex.match(line)
                if found:
                    setattr(vpc, attr, found.group(1))

            keepalive_regex = PEER_KEEPALIVE_REGEX.match(line)
            if keepalive_regex:
                destination, source, vrf = keepalive_regex.groups()
                vpc.peer_keepalive = {
                    "destination": destination,
                    "source": source,
                    "vrf": vrf or "management",   # nxos default keepalive vrf
                }
                continue

            auto_recovery_regex = AUTO_RECOVERY_REGEX.match(line)
            if auto_recovery_regex:
                vpc.auto_recovery = True
                vpc.auto_recovery_reload_delay = auto_recovery_regex.group(1)
                continue

            if line == "peer-switch":
                vpc.peer_switch = True
            elif line == "peer-gateway":
                vpc.peer_gateway = True
            elif line == "layer3 peer-router":
                vpc.layer3_peer_router = True
            elif line == "ip arp synchronize":
                vpc.ip_arp_synchronize = True

        # correlate peer-link and vpc-attached port-channels
        for intf_section in tree.find_objects(INTERFACE_REGEX):
            intf_name = INTERFACE_REGEX.match(intf_section.line).group(1)
            if intf_section.find_children(VPC_PEER_LINK_REGEX):
                vpc.peer_link = intf_name
                continue
            for child in intf_section.children:
                vpc_id_regex = VPC_ID_REGEX.match(child.line)
                if vpc_id_regex:
                    vpc.vpc_port_channels.append(
                        {"interface": intf_name, "vpc_id": vpc_id_regex.group(1)}
                    )

        if return_json:
            return vpc.to_dict()
        return vpc
