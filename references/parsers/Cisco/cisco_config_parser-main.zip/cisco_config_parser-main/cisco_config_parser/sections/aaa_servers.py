# Description: AAA server parser — TACACS+/RADIUS servers in both the
# modern named form (IOS-XE "tacacs server NAME" / "radius server NAME",
# DNAC-generated) and the legacy host form (IOS/NXOS "tacacs-server host"),
# plus server groups, CoA dynamic-author clients, radius-server attribute
# tuning and source-interfaces (incl. the XR form).
#
# Key hashes are detected (has_key) but never stored.

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DictMixin, mask_secrets

NAMED_SERVER_REGEX = re.compile(r"^(tacacs|radius) server\s+(\S+)")
LEGACY_SERVER_REGEX = re.compile(r"^(tacacs|radius)-server host\s+(\S+)(.*)")
ADDRESS_REGEX = re.compile(
    r"^address ipv[46]\s+(\S+)(?:\s+auth-port\s+(\d+))?(?:\s+acct-port\s+(\d+))?"
)
TIMEOUT_REGEX = re.compile(r"^timeout\s+(\d+)")
RETRANSMIT_REGEX = re.compile(r"^retransmit\s+(\d+)")
KEY_LINE_REGEX = re.compile(r"^key\s")

GROUP_REGEX = re.compile(r"^aaa group server (tacacs\+?|radius)\s+(\S+)")
# "server X" (NXOS), "server name X" (IOS-XE), "server-private X port N" (XR)
GROUP_SERVER_REGEX = re.compile(r"^server(?:-private)?(?:\s+name)?\s+(\S+)")
GROUP_SOURCE_INTERFACE_REGEX = re.compile(r"^(?:ip )?(?:tacacs|radius) source-interface\s+(\S+)|^source-interface\s+(\S+)")
GROUP_VRF_REGEX = re.compile(r"^(?:use-)?vrf\s+(\S+)")

DYNAMIC_AUTHOR_REGEX = re.compile(r"^aaa server radius dynamic-author")
DYNAMIC_AUTHOR_CLIENT_REGEX = re.compile(r"^client\s+(\S+)(.*)")

RADIUS_ATTRIBUTE_REGEX = re.compile(r"^radius-server attribute\s+(.*)")
GLOBAL_SOURCE_INTERFACE_REGEX = re.compile(
    r"^(?:ip )?(tacacs|radius)(?:-server)? source-interface\s+(\S+)(?:\s+vrf\s+(\S+))?"
)


@dataclass
class AAAServer(DictMixin):
    name: str = None
    protocol: str = None        # tacacs / radius
    style: str = None           # named / legacy
    address: str = None
    auth_port: str = None
    acct_port: str = None
    timeout: str = None
    retransmit: str = None
    has_key: bool = False
    children: list = field(default_factory=list)


@dataclass
class AAAServerGroup(DictMixin):
    name: str = None
    protocol: str = None        # tacacs / radius
    servers: list = field(default_factory=list)
    source_interface: str = None
    vrf: str = None
    children: list = field(default_factory=list)


@dataclass
class AAAServersConfig(DictMixin):
    servers: list = field(default_factory=list)
    groups: list = field(default_factory=list)
    dynamic_author_clients: list = field(default_factory=list)   # {client, has_key}
    radius_attributes: list = field(default_factory=list)
    source_interfaces: list = field(default_factory=list)        # {protocol, interface, vrf}


@dataclass
class AAAServersParser:
    content: str = None

    def _fetch_aaa_servers(self, return_json=False):
        """
        Fetch TACACS+/RADIUS server configuration from the config file
        :return: AAAServersConfig object
        """
        tree = ConfigTree(self.content)
        config = AAAServersConfig()

        for node in tree.root.children:
            line = node.line

            named_regex = NAMED_SERVER_REGEX.match(line)
            if named_regex:
                config.servers.append(self._parse_named_server(node, named_regex))
                continue

            legacy_regex = LEGACY_SERVER_REGEX.match(line)
            if legacy_regex:
                protocol, address, rest = legacy_regex.groups()
                config.servers.append(
                    AAAServer(
                        name=address,
                        protocol=protocol,
                        style="legacy",
                        address=address,
                        has_key=" key " in rest,
                        children=[mask_secrets(c) for c in node.child_lines()],
                    )
                )
                continue

            group_regex = GROUP_REGEX.match(line)
            if group_regex:
                config.groups.append(self._parse_group(node, group_regex))
                continue

            if DYNAMIC_AUTHOR_REGEX.match(line):
                for child in node.children:
                    client_regex = DYNAMIC_AUTHOR_CLIENT_REGEX.match(child.line)
                    if client_regex:
                        config.dynamic_author_clients.append({
                            "client": client_regex.group(1),
                            "has_key": "key" in client_regex.group(2),
                        })
                continue

            attribute_regex = RADIUS_ATTRIBUTE_REGEX.match(line)
            if attribute_regex:
                config.radius_attributes.append(attribute_regex.group(1).strip())
                continue

            source_regex = GLOBAL_SOURCE_INTERFACE_REGEX.match(line)
            if source_regex:
                protocol, interface, vrf = source_regex.groups()
                config.source_interfaces.append(
                    {"protocol": protocol, "interface": interface, "vrf": vrf}
                )

        if return_json:
            return config.to_dict()
        return config

    @staticmethod
    def _parse_named_server(node, named_regex):
        server = AAAServer(
            protocol=named_regex.group(1),
            name=named_regex.group(2),
            style="named",
            children=[mask_secrets(c) for c in node.child_lines()],
        )
        for child in node.children:
            address_regex = ADDRESS_REGEX.match(child.line)
            if address_regex:
                server.address, server.auth_port, server.acct_port = address_regex.groups()
                continue
            timeout_regex = TIMEOUT_REGEX.match(child.line)
            if timeout_regex:
                server.timeout = timeout_regex.group(1)
                continue
            retransmit_regex = RETRANSMIT_REGEX.match(child.line)
            if retransmit_regex:
                server.retransmit = retransmit_regex.group(1)
                continue
            if KEY_LINE_REGEX.match(child.line):
                server.has_key = True
        return server

    @staticmethod
    def _parse_group(node, group_regex):
        group = AAAServerGroup(
            protocol=group_regex.group(1).rstrip("+"),
            name=group_regex.group(2),
            children=[mask_secrets(line) for line, _ in node._walk()][1:],
        )
        for child in node.children:
            source_regex = GROUP_SOURCE_INTERFACE_REGEX.match(child.line)
            if source_regex:
                group.source_interface = source_regex.group(1) or source_regex.group(2)
                continue
            vrf_regex = GROUP_VRF_REGEX.match(child.line)
            if vrf_regex:
                group.vrf = vrf_regex.group(1)
                continue
            server_regex = GROUP_SERVER_REGEX.match(child.line)
            if server_regex:
                group.servers.append(server_regex.group(1))
        return group
