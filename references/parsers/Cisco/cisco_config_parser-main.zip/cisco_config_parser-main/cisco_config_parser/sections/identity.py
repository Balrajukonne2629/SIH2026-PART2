# Description: Device identity / management-plane parser: hostname, version,
# domain, name-servers, users, AAA, SNMP, NTP, logging, line vty/con and NXOS
# feature flags. These are the compliance staples.

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DeviceIdentity, User, LineConfig, SNMPConfig

HOSTNAME_REGEX = re.compile(r"^hostname\s+(\S+)")
VERSION_REGEX = re.compile(r"^version\s+(\S+.*)")
DOMAIN_REGEX = re.compile(r"^ip domain[- ]name\s+(\S+)")
NAME_SERVER_REGEX = re.compile(r"^ip name-server\s+(.*)")
USERNAME_REGEX = re.compile(r"^username\s+(\S+)(?:\s+privilege\s+(\d+))?.*?(secret|password)")
NTP_SERVER_REGEX = re.compile(r"^ntp server\s+(?:vrf\s+\S+\s+)?(\S+)(\s+prefer)?")
XR_NTP_SERVER_REGEX = re.compile(r"^server\s+(?:vrf\s+\S+\s+)?(\S+)(\s+prefer)?")
LOGGING_HOST_REGEX = re.compile(r"^logging(?:\s+host)?\s+(\d+\.\d+\.\d+\.\d+|\S+\.\S+)")
LOGGING_TRAP_REGEX = re.compile(r"^logging trap\s+(\S+)")
LINE_REGEX = re.compile(r"^line\s+(.*)")
FEATURE_REGEX = re.compile(r"^feature\s+(\S+.*)")

# mode/acl are only captured for known forms so NXOS keywords like
# "group network-operator" or "use-ipv4acl X" are not mistaken for an acl name
SNMP_COMMUNITY_REGEX = re.compile(
    r"^snmp-server community\s+(\S+)"
    r"(?:\s+(?:(RO|RW|ro|rw)|group\s+(\S+)|use-ipv4acl\s+(\S+)))?(?:\s+(\S+))?"
)
SNMP_LOCATION_REGEX = re.compile(r"^snmp-server location\s+(.*)")
SNMP_CONTACT_REGEX = re.compile(r"^snmp-server contact\s+(.*)")
SNMP_HOST_REGEX = re.compile(r"^snmp-server host\s+(\S+)\s+(.*)")
SNMP_USER_REGEX = re.compile(r"^snmp-server user\s+(\S+)\s+(.*)")

ACCESS_CLASS_REGEX = re.compile(r"^(?:ip )?access-class\s+(\S+)\s+in")
TRANSPORT_INPUT_REGEX = re.compile(r"^transport input\s+(.*)")
EXEC_TIMEOUT_REGEX = re.compile(r"^exec-timeout\s+(.*)")


@dataclass
class DeviceIdentityParser:
    content: str = None

    def _fetch_device_identity(self, return_json=False):
        """
        Fetch device identity and management-plane configuration
        :return: DeviceIdentity object
        """
        tree = ConfigTree(self.content)
        identity = DeviceIdentity(snmp=SNMPConfig())

        for node in tree.root.children:
            line = node.line

            for attr, regex in (
                ("hostname", HOSTNAME_REGEX),
                ("version", VERSION_REGEX),
                ("domain_name", DOMAIN_REGEX),
                ("logging_trap", LOGGING_TRAP_REGEX),
            ):
                found = regex.match(line)
                if found and getattr(identity, attr) is None:
                    setattr(identity, attr, found.group(1).strip())

            name_server_regex = NAME_SERVER_REGEX.match(line)
            if name_server_regex:
                identity.name_servers.extend(name_server_regex.group(1).split())

            username_regex = USERNAME_REGEX.match(line)
            if username_regex:
                identity.users.append(
                    User(
                        name=username_regex.group(1),
                        privilege=username_regex.group(2),
                        secret_type=username_regex.group(3),
                        raw=line,
                    )
                )

            ntp_regex = NTP_SERVER_REGEX.match(line)
            if ntp_regex:
                server = {"server": ntp_regex.group(1), "prefer": bool(ntp_regex.group(2))}
                identity.ntp_servers.append(server)

            # IOS-XR puts the servers inside a top-level "ntp" section
            if line == "ntp":
                for child in node.children:
                    xr_ntp_regex = XR_NTP_SERVER_REGEX.match(child.line)
                    if xr_ntp_regex:
                        identity.ntp_servers.append({
                            "server": xr_ntp_regex.group(1),
                            "prefer": bool(xr_ntp_regex.group(2)),
                        })

            if line.startswith("aaa "):
                identity.aaa.append(line)

            trap_regex = LOGGING_TRAP_REGEX.match(line)
            if not trap_regex:
                logging_regex = LOGGING_HOST_REGEX.match(line)
                if logging_regex:
                    identity.logging_hosts.append(logging_regex.group(1))

            feature_regex = FEATURE_REGEX.match(line)
            if feature_regex:
                identity.features.append(feature_regex.group(1).strip())

            if line.startswith("snmp-server"):
                self._parse_snmp_line(line, identity.snmp)

            line_regex = LINE_REGEX.match(line)
            if line_regex:
                identity.lines.append(self._parse_line_section(line_regex.group(1).strip(), node))

        if return_json:
            return identity.to_dict()
        return identity

    @staticmethod
    def _parse_snmp_line(line, snmp):
        community_regex = SNMP_COMMUNITY_REGEX.match(line)
        if community_regex:
            community, mode, group, ipv4acl, trailing_acl = community_regex.groups()
            snmp.communities.append({
                "community": community,
                "mode": mode.upper() if mode else None,
                "group": group,
                "acl": ipv4acl or (trailing_acl if mode else None),
            })
            return

        location_regex = SNMP_LOCATION_REGEX.match(line)
        if location_regex:
            snmp.location = location_regex.group(1).strip()
            return

        contact_regex = SNMP_CONTACT_REGEX.match(line)
        if contact_regex:
            snmp.contact = contact_regex.group(1).strip()
            return

        host_regex = SNMP_HOST_REGEX.match(line)
        if host_regex:
            snmp.hosts.append({"host": host_regex.group(1), "options": host_regex.group(2).strip()})
            return

        user_regex = SNMP_USER_REGEX.match(line)
        if user_regex:
            snmp.users.append({"user": user_regex.group(1), "options": user_regex.group(2).strip()})
            return

        snmp.children.append(line)

    @staticmethod
    def _parse_line_section(name, node):
        line_cfg = LineConfig(name=name, children=node.child_lines())
        for child_line in line_cfg.children:
            access_class_regex = ACCESS_CLASS_REGEX.match(child_line)
            if access_class_regex:
                line_cfg.access_class = access_class_regex.group(1)
                continue
            transport_regex = TRANSPORT_INPUT_REGEX.match(child_line)
            if transport_regex:
                line_cfg.transport_input = transport_regex.group(1).strip()
                continue
            timeout_regex = EXEC_TIMEOUT_REGEX.match(child_line)
            if timeout_regex:
                line_cfg.exec_timeout = timeout_regex.group(1).strip()
        return line_cfg
