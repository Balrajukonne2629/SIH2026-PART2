# Description: Access-list parser. Handles IOS named ACLs (ip access-list
# standard|extended NAME), IOS numbered ACLs (access-list N ...) and NXOS
# named ACLs (ip access-list NAME with sequenced entries).

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import AccessList, ACLEntry

# "ipv4/ipv6 access-list" is the IOS-XR form
NAMED_ACL_REGEX = re.compile(r"^ip(?:v[46])? access-list\s+(?:(standard|extended)\s+)?(\S+)")
NUMBERED_ACL_REGEX = re.compile(r"^access-list\s+(\d+)\s+(.*)")

PORT_OPERATORS = ("eq", "gt", "lt", "neq", "range")
IP_TOKEN_REGEX = re.compile(r"^\d+\.\d+\.\d+\.\d+$")


def _numbered_acl_type(number):
    number = int(number)
    if number < 100 or 1300 <= number <= 1999:
        return "standard"
    return "extended"


def _pop_address(tokens):
    """
    Consume an address term from the token list:
    any | host A.B.C.D | A.B.C.D WILDCARD | A.B.C.D/nn | object-group NAME
    """
    if not tokens:
        return None
    token = tokens.pop(0)
    if token in ("any", "any4", "any6"):
        return "any"
    if token == "host":
        return tokens.pop(0) if tokens else None
    if token in ("object-group", "addrgroup"):
        name = tokens.pop(0) if tokens else ""
        return f"{token} {name}".strip()
    if IP_TOKEN_REGEX.match(token) and tokens and IP_TOKEN_REGEX.match(tokens[0]):
        return f"{token} {tokens.pop(0)}"
    return token


def _pop_port(tokens):
    """
    Consume a port term (eq 22 / range 1000 2000 / gt 1023) if present
    """
    if not tokens or tokens[0] not in PORT_OPERATORS:
        return None
    operator = tokens.pop(0)
    if operator == "range":
        low = tokens.pop(0) if tokens else ""
        high = tokens.pop(0) if tokens else ""
        return f"range {low} {high}".strip()
    value = tokens.pop(0) if tokens else ""
    return f"{operator} {value}".strip()


def _parse_entry(entry_line, acl_type):
    """
    Parse a single permit/deny line into an ACLEntry
    :param entry_line: str (without the "access-list N" prefix for numbered acls)
    :param acl_type: standard / extended / unknown
    :return: ACLEntry or None if the line is not a permit/deny entry
    """
    tokens = entry_line.split()
    if not tokens:
        return None

    entry = ACLEntry(raw=entry_line)

    if tokens[0].isdigit():
        entry.sequence = tokens.pop(0)

    if not tokens or tokens[0] not in ("permit", "deny"):
        return None
    entry.action = tokens.pop(0)

    if acl_type == "standard":
        entry.source = _pop_address(tokens)
    else:
        entry.protocol = tokens.pop(0) if tokens else None
        entry.source = _pop_address(tokens)
        entry.source_port = _pop_port(tokens)
        entry.destination = _pop_address(tokens)
        entry.destination_port = _pop_port(tokens)

    if tokens:
        entry.options = " ".join(tokens)
    return entry


@dataclass
class ACLParser:
    content: str = None

    def _fetch_access_lists(self, return_json=False):
        """
        Fetch all access-lists from the config file
        :return: list of AccessList objects
        """
        tree = ConfigTree(self.content)
        access_lists = []

        # ---- named ACLs (IOS "ip access-list standard|extended NAME", NXOS "ip access-list NAME")
        for section in tree.find_objects(NAMED_ACL_REGEX):
            acl_regex = NAMED_ACL_REGEX.match(section.line)
            acl_type = acl_regex.group(1) or "extended"
            acl = AccessList(name=acl_regex.group(2), type=acl_type, style="named")

            for child in section.children:
                line = child.line
                remark_regex = re.match(r"^(?:\d+\s+)?remark\s+(.*)", line)
                if remark_regex:
                    acl.remarks.append(remark_regex.group(1).strip())
                    continue
                entry = _parse_entry(line, acl_type)
                if entry:
                    acl.entries.append(entry)

            access_lists.append(acl)

        # ---- numbered ACLs ("access-list 110 permit ...") grouped by number
        numbered = {}
        for node in tree.find_objects(NUMBERED_ACL_REGEX):
            acl_regex = NUMBERED_ACL_REGEX.match(node.line)
            number, rest = acl_regex.group(1), acl_regex.group(2).strip()
            acl_type = _numbered_acl_type(number)

            acl = numbered.get(number)
            if acl is None:
                acl = AccessList(name=number, type=acl_type, style="numbered")
                numbered[number] = acl
                access_lists.append(acl)

            if rest.startswith("remark"):
                acl.remarks.append(rest.replace("remark", "", 1).strip())
                continue
            entry = _parse_entry(rest, acl_type)
            if entry:
                acl.entries.append(entry)

        if return_json:
            return [acl.to_dict() for acl in access_lists]
        return access_lists
