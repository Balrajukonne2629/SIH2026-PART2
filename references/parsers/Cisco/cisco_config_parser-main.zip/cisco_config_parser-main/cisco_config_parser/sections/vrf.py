# Description: VRF definition parser. Handles IOS "vrf definition NAME",
# legacy IOS "ip vrf NAME", NXOS "vrf context NAME" and XR "vrf NAME".

import re
from dataclasses import dataclass

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import VRF, VRFAddressFamily

VRF_SECTION_REGEX = re.compile(r"^(?:vrf definition|ip vrf|vrf context|vrf)\s+(\S+)$")
RD_REGEX = re.compile(r"^rd\s+(\S+)")
RT_REGEX = re.compile(r"^route-target\s+(import|export|both)\s+(\S+)")
AF_REGEX = re.compile(r"^address-family\s+(.*)")


@dataclass
class VRFParser:
    content: str = None

    def _fetch_vrfs(self, return_json=False):
        """
        Fetch all VRF definitions from the config file
        :return: list of VRF objects
        """
        tree = ConfigTree(self.content)
        vrfs = []

        for section in tree.find_objects(VRF_SECTION_REGEX):
            name = VRF_SECTION_REGEX.match(section.line).group(1)
            vrf = VRF(name=name, children=section.child_lines())

            for child in section.children:
                rd_regex = RD_REGEX.match(child.line)
                if rd_regex:
                    vrf.rd = rd_regex.group(1)
                    continue

                if child.line.startswith("description "):
                    vrf.description = child.line.replace("description ", "", 1).strip()
                    continue

                # route-targets configured directly under the vrf (legacy "ip vrf")
                self._collect_route_target(child.line, vrf_af=None, vrf=vrf)

                af_regex = AF_REGEX.match(child.line)
                if af_regex:
                    af = VRFAddressFamily(
                        name=af_regex.group(1).strip(),
                        children=child.child_lines(),
                    )
                    for af_child in child.children:
                        self._collect_route_target(af_child.line, vrf_af=af, vrf=None)

                        # XR nests targets under import/export route-target blocks
                        if af_child.line in ("import route-target", "export route-target"):
                            targets = [t.line for t in af_child.children]
                            if af_child.line.startswith("import"):
                                af.route_target_import.extend(targets)
                            else:
                                af.route_target_export.extend(targets)

                    vrf.address_families.append(af)

            vrfs.append(vrf)

        if return_json:
            return [vrf.to_dict() for vrf in vrfs]
        return vrfs

    @staticmethod
    def _collect_route_target(line, vrf_af=None, vrf=None):
        """
        Add a "route-target import|export|both X" line to the right bucket
        """
        rt_regex = RT_REGEX.match(line)
        if not rt_regex:
            return
        direction, target = rt_regex.groups()

        if vrf_af is not None:
            import_list = vrf_af.route_target_import
            export_list = vrf_af.route_target_export
        elif vrf is not None:
            # legacy style: keep them on a synthetic ipv4 address-family
            if not vrf.address_families:
                vrf.address_families.append(VRFAddressFamily(name="ipv4"))
            import_list = vrf.address_families[0].route_target_import
            export_list = vrf.address_families[0].route_target_export
        else:
            return

        if direction in ("import", "both"):
            import_list.append(target)
        if direction in ("export", "both"):
            export_list.append(target)
