# Description: Port-channel / link-aggregation parser. Correlates the
# bundle interfaces (IOS/NXOS Port-channel, XR Bundle-Ether) with their
# member interfaces ("channel-group N mode X" / XR "bundle id N mode X").

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DictMixin

INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")
PORT_CHANNEL_INTF_REGEX = re.compile(r"^interface\s+(?:[Pp]ort-channel|Bundle-Ether)(\d+)(?:\.\d+)?$")
CHANNEL_GROUP_REGEX = re.compile(r"^channel-group\s+(\d+)(?:\s+mode\s+(\S+))?")
BUNDLE_ID_REGEX = re.compile(r"^bundle id\s+(\d+)(?:\s+mode\s+(\S+))?")
DESCRIPTION_REGEX = re.compile(r"^description\s+(.*)")
VPC_REGEX = re.compile(r"^vpc\s+(\S+)")

# member modes that imply LACP vs static bundling
LACP_MODES = {"active", "passive"}


@dataclass
class PortChannel(DictMixin):
    name: str = None            # e.g. Port-channel1 / Bundle-Ether1
    id: str = None
    description: str = None
    protocol: str = None        # lacp / pagp / static
    vpc: str = None             # NXOS vpc id (or "peer-link")
    members: list = field(default_factory=list)    # {interface, mode}
    children: list = field(default_factory=list)


@dataclass
class PortChannelParser:
    content: str = None

    def _fetch_port_channels(self, return_json=False):
        """
        Fetch all port-channels with their member interfaces
        :return: list of PortChannel objects
        """
        tree = ConfigTree(self.content)
        port_channels = {}

        def get_port_channel(po_id):
            if po_id not in port_channels:
                port_channels[po_id] = PortChannel(id=po_id)
            return port_channels[po_id]

        for intf_section in tree.find_objects(INTERFACE_REGEX):
            intf_name = INTERFACE_REGEX.match(intf_section.line).group(1)

            po_regex = PORT_CHANNEL_INTF_REGEX.match(intf_section.line)
            if po_regex and "." not in intf_name:
                port_channel = get_port_channel(po_regex.group(1))
                port_channel.name = intf_name
                port_channel.children = intf_section.child_lines()
                for child in intf_section.children:
                    description_regex = DESCRIPTION_REGEX.match(child.line)
                    if description_regex:
                        port_channel.description = description_regex.group(1).strip()
                    vpc_regex = VPC_REGEX.match(child.line)
                    if vpc_regex:
                        port_channel.vpc = vpc_regex.group(1)
                continue

            for child in intf_section.children:
                member_regex = CHANNEL_GROUP_REGEX.match(child.line) or BUNDLE_ID_REGEX.match(child.line)
                if member_regex:
                    port_channel = get_port_channel(member_regex.group(1))
                    mode = member_regex.group(2)
                    port_channel.members.append({"interface": intf_name, "mode": mode})
                    if mode in LACP_MODES:
                        port_channel.protocol = "lacp"
                    elif mode in ("desirable", "auto"):
                        port_channel.protocol = "pagp"
                    elif mode == "on" and port_channel.protocol is None:
                        port_channel.protocol = "static"

        result = list(port_channels.values())
        if return_json:
            return [po.to_dict() for po in result]
        return result
