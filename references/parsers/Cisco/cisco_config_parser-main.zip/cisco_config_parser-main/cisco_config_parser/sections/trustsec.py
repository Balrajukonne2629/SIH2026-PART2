# Description: Cisco TrustSec (CTS) parser for IOS-XE — the SD-Access /
# ISE segmentation config: authorization list, SXP peering, role-based
# enforcement, static IP-to-SGT maps, SGACL permission matrix and the
# per-interface "cts manual" blocks.
#
# Secrets (sxp default password, key hashes) are detected but never stored.

import re
from dataclasses import dataclass, field

from cisco_config_parser.config_tree import ConfigTree
from .section_obj import DictMixin

AUTHORIZATION_LIST_REGEX = re.compile(r"^cts authorization list\s+(\S+)")
SXP_ENABLE_REGEX = re.compile(r"^cts sxp enable")
SXP_DEFAULT_PASSWORD_REGEX = re.compile(r"^cts sxp default password")
SXP_CONNECTION_REGEX = re.compile(
    r"^cts sxp connection peer\s+(\S+)"
    r"(?:\s+source\s+(\S+))?"
    r"(?:\s+password\s+(\S+))?"
    r"(?:\s+mode\s+(local|peer)\s+(speaker|listener|both))?"
    r"(?:\s+hold-time\s+\d+\s+\d+)?"
    r"(?:\s+vrf\s+(\S+))?"
)
ENFORCEMENT_REGEX = re.compile(r"^cts role-based enforcement$")
ENFORCEMENT_VLAN_REGEX = re.compile(r"^cts role-based enforcement vlan-list\s+(\S+)")
SGT_MAP_REGEX = re.compile(
    r"^cts role-based sgt-map\s+(?:vrf\s+(\S+)\s+)?(?:vlan-list\s+(\S+)|(\S+))\s+sgt\s+(\d+)"
)
PERMISSIONS_REGEX = re.compile(r"^cts role-based permissions from\s+(\d+)\s+to\s+(\d+)\s+(.*)")
PERMISSIONS_DEFAULT_REGEX = re.compile(r"^cts role-based permissions default\s+(.*)")

INTERFACE_REGEX = re.compile(r"^interface\s+(\S+)")
CTS_MANUAL_REGEX = re.compile(r"^cts manual$")
STATIC_SGT_REGEX = re.compile(r"^policy static sgt\s+(\d+)(\s+trusted)?")
NO_PROPAGATE_REGEX = re.compile(r"^no propagate sgt")
NO_ENFORCEMENT_REGEX = re.compile(r"^no cts role-based enforcement")


@dataclass
class CTSInterface(DictMixin):
    interface: str = None
    mode: str = None            # manual
    static_sgt: str = None
    trusted: bool = False
    propagate_sgt: bool = True
    children: list = field(default_factory=list)


@dataclass
class CTSConfig(DictMixin):
    authorization_list: str = None
    sxp_enabled: bool = False
    sxp_default_password: bool = False
    sxp_connections: list = field(default_factory=list)
    enforcement: bool = False
    enforcement_vlan_lists: list = field(default_factory=list)
    enforcement_disabled_interfaces: list = field(default_factory=list)
    sgt_maps: list = field(default_factory=list)        # {vrf, address, sgt}
    permissions: list = field(default_factory=list)     # {from_sgt, to_sgt, sgacls}
    default_permissions: list = field(default_factory=list)
    interfaces: list = field(default_factory=list)


@dataclass
class TrustSecParser:
    content: str = None

    def _fetch_trustsec(self, return_json=False):
        """
        Fetch the TrustSec configuration from the config file
        :return: CTSConfig object (fields empty when cts is not configured)
        """
        tree = ConfigTree(self.content)
        cts = CTSConfig()

        for node in tree.root.children:
            line = node.line

            auth_regex = AUTHORIZATION_LIST_REGEX.match(line)
            if auth_regex:
                cts.authorization_list = auth_regex.group(1)
                continue

            if SXP_ENABLE_REGEX.match(line):
                cts.sxp_enabled = True
                continue

            if SXP_DEFAULT_PASSWORD_REGEX.match(line):
                # the hash itself is deliberately not stored
                cts.sxp_default_password = True
                continue

            sxp_regex = SXP_CONNECTION_REGEX.match(line)
            if sxp_regex:
                peer, source, password, mode_side, mode_role, vrf = sxp_regex.groups()
                cts.sxp_connections.append({
                    "peer": peer,
                    "source": source,
                    "password": password,       # keyword (default/none), not a secret
                    "mode": f"{mode_side} {mode_role}" if mode_side else None,
                    "vrf": vrf,
                })
                continue

            if ENFORCEMENT_REGEX.match(line):
                cts.enforcement = True
                continue

            vlan_regex = ENFORCEMENT_VLAN_REGEX.match(line)
            if vlan_regex:
                cts.enforcement_vlan_lists.append(vlan_regex.group(1))
                continue

            sgt_map_regex = SGT_MAP_REGEX.match(line)
            if sgt_map_regex:
                vrf, vlan_list, address, sgt = sgt_map_regex.groups()
                cts.sgt_maps.append({
                    "vrf": vrf, "address": address, "vlan_list": vlan_list, "sgt": sgt,
                })
                continue

            permissions_regex = PERMISSIONS_REGEX.match(line)
            if permissions_regex:
                from_sgt, to_sgt, sgacls = permissions_regex.groups()
                cts.permissions.append({
                    "from_sgt": from_sgt,
                    "to_sgt": to_sgt,
                    "sgacls": sgacls.split(),
                })
                continue

            default_regex = PERMISSIONS_DEFAULT_REGEX.match(line)
            if default_regex:
                cts.default_permissions = default_regex.group(1).split()

        # per-interface cts blocks
        for intf_section in tree.find_objects(INTERFACE_REGEX):
            intf_name = INTERFACE_REGEX.match(intf_section.line).group(1)

            if intf_section.find_children(NO_ENFORCEMENT_REGEX):
                cts.enforcement_disabled_interfaces.append(intf_name)

            for child in intf_section.children:
                if not CTS_MANUAL_REGEX.match(child.line):
                    continue
                cts_intf = CTSInterface(
                    interface=intf_name,
                    mode="manual",
                    children=child.child_lines(),
                )
                for manual_child in child.children:
                    sgt_regex = STATIC_SGT_REGEX.match(manual_child.line)
                    if sgt_regex:
                        cts_intf.static_sgt = sgt_regex.group(1)
                        cts_intf.trusted = bool(sgt_regex.group(2))
                    if NO_PROPAGATE_REGEX.match(manual_child.line):
                        cts_intf.propagate_sgt = False
                cts.interfaces.append(cts_intf)

        if return_json:
            return cts.to_dict()
        return cts
