JUNIPER JUNOS SAMPLE CONFIGURATION

Filename:
sample_juniper_junos_configuration.conf

Type:
Synthetic lab configuration

Purpose:
This file is intended for testing Junos configuration parsing,
vendor identification, configuration extraction, and compliance
rule evaluation.

Included Configuration Sections:
- system
- services
- login
- ntp
- interfaces
- routing-options
- protocols
- snmp
- firewall

Important:
This is not a production configuration.
All addresses are documentation/test addresses.
Credentials are redacted and must not be used.
The SNMP community "public" is intentionally included as an
insecure example for compliance-audit testing.

Potential Compliance Checks:
- SSH protocol version
- Weak or default SNMP community
- NTP server configuration
- Interface descriptions
- Interface IP addressing
- OSPF configuration
- LLDP configuration
- Default route
- Control-plane firewall policy
- Presence of encrypted authentication data